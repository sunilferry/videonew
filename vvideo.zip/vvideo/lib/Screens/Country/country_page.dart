import 'dart:ui';

import 'package:agora_video_app/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:velocity_x/velocity_x.dart';

class CountryPage extends StatelessWidget {
  var countryList = [
    'India',
    'Pakistan',
    'Saudi Arabia',
    'Egypt',
    'Indonesia',
    'Kuwait',
    'Morocco',
    'USA',
    'Philippines',
    'Japan',
    'Russia',
    'Brazil',
    'China',
    'Canada',
    'Kazakhstan',
    'Algeria',
    'Mexico',
    'Nepal'
  ];

  List flags= ['india.svg','pakistan.svg','saudi.svg','egypt.svg','indonesia.svg','kuwait.svg','morocco.svg','usa.svg','philippines.svg','japan.svg','russia.svg','brazil.svg'
   ,'china.svg','canada.svg','kazakhstan.svg','algeria.svg','mexico.svg','nepal.svg'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Stack(
        children: <Widget>[
          Container(
            height: 300,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF9065F7), kPinkColor])),
          ),
          Container(
            margin: EdgeInsets.only(top: 280),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24))),
          ),
          Column(
            children: [
              SafeArea(
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        )),
                    Text(
                      'Select Country',
                      style: TextStyle(color: Colors.white),
                    )
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.4),
                      spreadRadius: 10,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                margin: EdgeInsets.only(left: 24, right: 24, top: 100),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 5.0),
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: new BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.purple.shade200.withOpacity(0.5),
                                Color(0xFFF3EB9B).withOpacity(0.5),
                              ]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Container(
                        margin: EdgeInsets.only(left: 8, right: 8),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            16.heightBox,
                            Text(
                              'Top Countries',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                            LimitedBox(
                              maxHeight: context.screenHeight-220,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: countryList.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                      height: 40,
                                      margin: EdgeInsets.all(8),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              SvgPicture.asset('assets/icons/${flags[index]}',height: 18,),
                                              16.widthBox,
                                              Text(countryList[index]),
                                            ],
                                          ),

                                        ],
                                      ),
                                    );
                                  }),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

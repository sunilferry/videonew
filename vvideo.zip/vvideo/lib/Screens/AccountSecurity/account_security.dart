import 'package:agora_video_app/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:velocity_x/velocity_x.dart';
class AccountSecurity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.black
        ),
        title: Text('Account Security',style: TextStyle(color:Colors.black,fontSize: 16),),
      ),
      body: Container(
        margin: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SvgPicture.asset('assets/icons/facebook.svg',height: 24,),
                Container(
                    width: 80,
                    height: 30,
                    child: ElevatedButton(onPressed: (){}, child: Text('Bind',style: TextStyle(color: kPrimaryColor),),
                      style: ElevatedButton.styleFrom(side: BorderSide(width: 1.0, color:kPrimaryColor,),
                          primary: Colors.white
                      ),))
              ],
            ),
            16.heightBox,
            Divider(
              height: 1,
              color: Colors.grey[300],
            ),
            16.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(Icons.call,size: 24,),
                Container(
                    width: 80,
                    height: 30,
                    child: ElevatedButton(onPressed: (){}, child: Text('Bind',style: TextStyle(color: kPrimaryColor),),
                    style: ElevatedButton.styleFrom(side: BorderSide(width: 1.0, color:kPrimaryColor,),
                    primary: Colors.white
                    ),
                    ))
              ],
            ),

            16.heightBox,
            Divider(
              height: 1,
              color: Colors.grey[300],
            ),
            16.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SvgPicture.asset('assets/icons/twitter.svg',height: 24,),
                Container( width: 80, height: 30,child: ElevatedButton(onPressed: (){}, child: Text('Unbind')))
              ],
            ),

            16.heightBox,
            Divider(
              height: 1,
              color: Colors.grey[300],
            )

          ],
        ),
      ),
    );
  }
}

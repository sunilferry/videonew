import 'dart:ui';

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class Setting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                gradient: RadialGradient(colors: [kPinkColor, Colors.white])),
            height: 300,
            width: 300,
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Container(
              decoration: BoxDecoration(
                  gradient:
                      RadialGradient(colors: [kPrimaryColor, Colors.white])),
              height: 300,
              width: 300,
            ),
          ),
          new ClipRect(
            child: new BackdropFilter(
              filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
              child: new Container(
                decoration: new BoxDecoration(
                    color: Colors.grey.shade200.withOpacity(0.5)),
                child: SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: Icon(Icons.arrow_back)),
                          Expanded(
                              child: Text(
                            'Settings',
                            textAlign: TextAlign.center,
                          ))
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      InkWell(
                          onTap: (){
                            Navigator.pushNamed(context, INVITATION);
                          },
                          child: menuItem('Invitation', Icon(Icons.share))),
                      InkWell(
                          onTap: (){
                            Navigator.pushNamed(context, ACCOUNT_SECURITY);
                          },
                          child: menuItem('Account Security', Icon(Icons.security))),
                      InkWell(
                        onTap: (){
                          Navigator.pushNamed(context, LIVE_DATA);
                        },
                        child: menuItem(
                            'Host Data', Icon(Icons.perm_data_setting_rounded)),
                      ),
                      InkWell(
                        onTap: (){
                          Navigator.pushNamed(context, HOST_VERIFICATION);
                        },
                        child: menuItem('Host Verification',
                            Icon(Icons.verified_user_outlined)),
                      ),
                      menuItem('About Us', Icon(Icons.info_outline)),
                      menuItem('Agreement', Icon(Icons.support)),
                      menuItem(
                          'Privacy Policy', Icon(Icons.privacy_tip_outlined)),
                      menuItem('Cache Cleaner', Icon(Icons.clean_hands)),

                      20.heightBox,
                      Align(
                        alignment: Alignment.center,
                        child: InkWell(
                          onTap: (){
                            Navigator.pushReplacementNamed(context, LOGIN);
                          },
                          child: Container(
                            height: 40,
                            width: 100,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(6)
                            ),
                            child: Center(
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.logout,color: kPrimaryColor,),
                                  10.widthBox,
                                  Text('Logout',style: TextStyle(color: kPrimaryColor),),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget menuItem(String title, Widget icon) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              icon,
              SizedBox(
                width: 20,
              ),
              Text('$title')
            ],
          ),
          Icon(
            Icons.arrow_forward_ios,
            size: 18,
          ),
        ],
      ),
    );
  }
}

import 'dart:ui';

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/base_stateless.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class ConvertDiamond extends BaseStateLess {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Stack(
        children: <Widget>[
          Container(
            height: 300,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF9065F7), kPinkColor])),
          ),
          Container(
            margin: EdgeInsets.only(top: 250),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24))),
          ),
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.purple.withOpacity(0.4),
                        spreadRadius: 10,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  margin: EdgeInsets.only(left: 24, right: 24, top: 120),
                  child: new ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: new BackdropFilter(
                      filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 5.0),
                      child: new Container(
                        width: MediaQuery.of(context).size.width,
                        height: 200.0,
                        decoration: new BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.bottomLeft,
                                end: Alignment.topRight,
                                colors: [
                                  Colors.purple.shade200.withOpacity(0.5),
                                  Color(0xFFF3EB9B).withOpacity(0.5),
                                ]),
                            borderRadius: BorderRadius.circular(8)),
                        child: Container(
                          child: Stack(
                            children: [
                              Container(
                                margin:EdgeInsets.only(left: 8,right: 8,bottom: 50),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'V VIDEO',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                              fontStyle: FontStyle.italic),
                                        )
                                      ],
                                    ),
                                    Text(
                                      '9524 4587 5645 4582',
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white),
                                    ),
                                  Align(
                                    alignment: Alignment.bottomRight,
                                    child:  Container(
                                      decoration: BoxDecoration(
                                          color: Colors.black12,
                                          borderRadius: BorderRadius.circular(6)),
                                      padding: EdgeInsets.only(
                                          left: 8, right: 8, top: 8, bottom: 8),
                                      child: Text(
                                        'Show CVV',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white),
                                      ),
                                    ),
                                  )

                                  ],

                                ),
                              ),

                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  padding: EdgeInsets.only(left: 16),
                                  height: 50,
                                  width: context.screenWidth,
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          colors: [kPrimaryColor,kPinkColor]
                                      )
                                  ),
                                  child:    Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text('Diamond',style: TextStyle(color: Colors.white,fontSize: 12),),
                                      Text(
                                        '250000000000000',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('\u2022 Minimum exchange of 100 diamonds'),
                        4.heightBox,
                        Text(
                            '\u2022 The gift you receive will be automatically converted into diamonds'),
                        4.heightBox,
                        Text('\u2022 The ratio of diamonds to coins 1:1'),
                        16.heightBox,
                        Stack(
                          children: [
                            TextField(
                              decoration: InputDecoration(
                                hintText: 'Enter diamond amount',
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.all(8),
                              ),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {},
                            ),
                            Container(
                              height: 35,
                                margin: EdgeInsets.only(right: 8,top: 6),
                                alignment: Alignment.centerRight,
                                child: ElevatedButton(
                                    onPressed: () {}, child: Text('ALL')))
                          ],
                        ),
                        16.heightBox,
                        Row(
                          children: [
                            Text('Exchange the coin : '),
                            Text(
                              '100 coins',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: kPrimaryColor),
                            )
                          ],
                        ),
                        32.heightBox,
                        Container(
                            width: context.screenWidth,
                            child: ElevatedButton(
                                onPressed: () {
                                  showMessage('Converted', context);
                                },
                                child: Text('Exchange the coins')))
                      ],
                    )),
              ],
            ),
          ),
          SafeArea(
            child: Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

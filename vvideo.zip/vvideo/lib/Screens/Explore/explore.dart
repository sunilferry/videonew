import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../constants.dart';

class Explore extends StatelessWidget {
  List countries= ['India','Pakistan','Saudi Arabia','Egypt','Indonesia','Kuwait','Morocco','More'];
  List flags= ['india.svg','pakistan.svg','saudi.svg','egypt.svg','indonesia.svg','kuwait.svg','morocco.svg','more.svg'];
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Color(0xCD0DA8)));
    return Material(
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                  Color(0xFFFBECF1),
                  Color(0xFFEEEBF0),
                ])),
          ),
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 120,
                    child: ListView(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      children: [
                        getCategory('#New Host'),
                        getCategory('#Hot'),
                        getCategory('#Love'),
                        getCategory('#Romance'),
                      ],
                    ),
                  ),
                  8.heightBox,
                  Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 8),
                        width: 2,
                        height: 30,
                        color: Colors.pink,
                      ),
                      8.widthBox,
                      Text(
                        'Countries & Regions',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  8.heightBox,
                  GridView.builder(
                      physics: ClampingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: countries.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        childAspectRatio: 2.2,
                      ),
                      itemBuilder: (BuildContext context, int index) {
                        return Center(
                          child: Container(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SvgPicture.asset('assets/icons/${flags[index]}',height: 18,),
                                4.heightBox,
                                Text(
                                  countries[index],
                                  style:
                                      TextStyle(fontSize: 12, color: Colors.black),
                                ),

                              ],
                            ),
                          ),
                        ).onTap(() {
                          print(index);
                          if(index==7){
                            Navigator.pushNamed(context, COUNTRY);
                          }
                        });
                      }),

                  8.heightBox,
                  Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 8),
                        width: 2,
                        height: 30,
                        color: Colors.pink,
                      ),
                      8.widthBox,
                      Text(
                        'Hot Live',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  8.heightBox,
                  Container(
                    margin: EdgeInsets.only(left: 4,right: 4,bottom: 16),
                    child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        primary: false,
                        gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          childAspectRatio: 2/2.2,
                        ),
                        itemCount: 8,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            margin: EdgeInsets.all(4),
                            child: Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(

                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.fill,
                                          image: NetworkImage(
                                            "https://hips.hearstapps.com/esquireuk.cdnds.net/17/43/carolineannkelley.jpg?crop=1xw:1.0xh;center,top&resize=480:*",
                                          ),
                                        ),
                                      )
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                            begin: Alignment.topCenter,
                                            end: Alignment.bottomCenter,
                                            colors: [
                                              Color(0x13000000),
                                              Colors.black38,
                                            ]),
                                        borderRadius: BorderRadius.circular(8)
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(height: 8,),
                                        Container(
                                            margin: EdgeInsets.only(left: 8),
                                            child: Text(
                                              'Love for romance',
                                              style: TextStyle(color: Colors.white,fontSize: 14),
                                            )),
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: 8,
                                            ),
                                            Image.asset(
                                              'assets/icons/india.png',
                                              height: 18,
                                            ),
                                            SizedBox(
                                              width: 4,
                                            ),
                                            Text(
                                              'IND',
                                              style: TextStyle(
                                                  color: Colors.white, fontSize: 10),
                                            ),
                                            Container(
                                              margin: EdgeInsets.only(left: 4),
                                              padding: EdgeInsets.only(left: 6,right: 6,top: 2,bottom: 2),
                                              decoration: BoxDecoration(
                                                  color: kPrimaryColor,
                                                  borderRadius: BorderRadius.circular(8)
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Image.asset('assets/icons/star.png',height: 12,),
                                                  SizedBox(width: 2,),
                                                  Text('Lv0',style: TextStyle(color: Colors.white,fontSize: 10),)
                                                ],
                                              ),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          );
                        }),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  getCategory(String title) {
    return Container(
      height: 100,
      width: 100,
      margin: EdgeInsets.all(8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/girl.jpg',
              fit: BoxFit.cover,
            ),
            Container(
              padding: EdgeInsets.only(bottom: 4),
              alignment: Alignment.bottomCenter,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                    Color(0x169C27B0),
                    Color(0x529C27B0),
                    Color(0xBA9C27B0),
                  ])),
              child: Text(
                title,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}

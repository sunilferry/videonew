import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:velocity_x/velocity_x.dart';

class Cars extends StatefulWidget {
  @override
  _CarsState createState() => _CarsState();
}

class _CarsState extends State<Cars> {
  @override
  Widget build(BuildContext context) {
    final double itemHeight = (context.screenHeight) / 3;
    final double itemWidth = context.screenWidth / 1.8;
    return Container(
      margin: EdgeInsets.only(left: 8, right: 8),
      child: GridView.builder(
          physics: ClampingScrollPhysics(),
          shrinkWrap: true,
          itemCount: 9,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: (itemWidth / itemHeight),
          ),
          itemBuilder: (BuildContext context, int index) {
            return Container(
              margin: EdgeInsets.all(8),
              child: new ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: new BackdropFilter(
                  filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                  child: new Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: new BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.bottomLeft,
                            end: Alignment.topRight,
                            colors: [
                              Colors.purple.shade200.withOpacity(0.5),
                              Color(0xFFF3EB9B).withOpacity(0.5),
                            ]),
                        borderRadius: BorderRadius.circular(8)),
                    child: Container(
                      margin: EdgeInsets.all(8),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.arrow_drop_down),
                              Text(
                                '10 days',
                                style: TextStyle(fontSize: 10),
                              )
                            ],
                          ),
                          10.heightBox,
                          Lottie.asset('assets/json_files/car.json',
                              height: context.percentHeight * 8),
                          8.heightBox,
                          Text(
                            'Car',
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                          4.heightBox,
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Image.asset(
                                'assets/icons/diamond.png',
                                height: 18,
                                width: 18,
                              ),
                              4.widthBox,
                              Text(
                                '200',
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
    );
  }
}

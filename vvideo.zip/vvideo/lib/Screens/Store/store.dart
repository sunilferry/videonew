import 'package:agora_video_app/Screens/Store/cars.dart';
import 'package:agora_video_app/constants.dart';
import 'package:flutter/material.dart';

class Store extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          iconTheme: IconThemeData(
              color: Colors.black
          ),
          elevation: 0,
          title: Text('Store',style: TextStyle(color: Colors.black,fontSize: 14),),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: (){
              Navigator.pop(context);
            },
          ),
        ),
        body: SafeArea(
          child: Column(
            children: [
              Container(
                height: 45,
                margin: EdgeInsets.only(left: 24,right: 24),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(25.0,),
                ),
                child: TabBar(
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(25.0,),
                      gradient: LinearGradient(
                          begin: Alignment.bottomLeft,
                          end: Alignment.topRight,
                          colors: [
                            Colors.purple.shade200.withOpacity(0.5),
                            kPrimaryColor.withOpacity(0.5),
                          ]),
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.black,
                  tabs: [
                    Tab(text: 'Entry',),
                    Tab(text: 'Lucky ID',),
                  ],
                ),
              ),

              Expanded(
                child: TabBarView(
                  children: [
                    Cars(),
                    Cars()
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../config.dart';
import '../../constants.dart';

class Invitation extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Color(0xCD0DA8)));
    return Material(
      child: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [kPinkColor, kPrimaryColor])),
            height: 200,
            width: context.screenWidth,
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(left: 16, right: 16, top: 140),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                    child: new Container(
                      decoration: new BoxDecoration(
                          color: Colors.grey.shade200.withOpacity(0.5)),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: 60,
                          ),
                          Text(default_name),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    '0',
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text('Diamond Income',
                                      style: TextStyle(fontSize: 12)),
                                ],
                              ),
                              Column(
                                children: [
                                  Text(
                                    '0',
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text('Share', style: TextStyle(fontSize: 12)),
                                ],
                              )
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.all(16),
                child: Container(
                  height: 40,
                  margin: EdgeInsets.all(8),
                  child: Row(
                    children: [
                      Flexible(
                        child: TextField(
                          decoration: InputDecoration(
                              hintText: 'Invitation Code',
                              filled: true,
                              fillColor: Colors.grey[200],
                              contentPadding: EdgeInsets.only(
                                  left: 8, right: 8),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(4),
                                  borderSide: BorderSide.none),
                          ),
                        ),
                      ),
                      16.widthBox,
                      ElevatedButton(onPressed: () {}, child: Text('Submit')),
                    ],
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.all(16),
                child: Container(
                  margin: EdgeInsets.all(8),
                  child: Column(
                    children: [
                      8.heightBox,
                      Row(
                        children: [
                          Icon(Icons.person),
                          8.widthBox,
                          Text('Invite Friends '),
                          10.widthBox,
                          Text('+100 diamonds'),
                          Expanded(
                              child: Align(
                                  alignment: Alignment.topRight,
                                  child: Icon(
                                    Icons.arrow_forward_ios,
                                    size: 18,
                                  )))
                        ],
                      ),
                      24.heightBox,
                      Row(
                        children: [
                          Icon(Icons.share),
                          8.widthBox,
                          Text('Share '),
                          10.widthBox,
                          Text(''),
                          Expanded(
                              child: Align(
                                  alignment: Alignment.topRight,
                                  child: Icon(
                                    Icons.arrow_forward_ios,
                                    size: 18,
                                  )))
                        ],
                      ),
                      8.heightBox,
                    ],
                  ),
                ),
              )
            ],
          ),
          Container(
              alignment: Alignment.topCenter,
              margin: EdgeInsets.only(top: 120),
              child: 'assets/images/girl.jpg'.circularAssetImage(radius: 30)),
          SafeArea(
            child: Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    )),
              ],
            ),
          )
        ],
      ),
    );
  }
}

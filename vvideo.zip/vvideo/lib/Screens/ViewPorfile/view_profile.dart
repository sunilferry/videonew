import 'dart:ui';

import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../constants.dart';

class ViewProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Color(0xCD0DA8)));
    return Material(
      child: Stack(
        children: [
          Container(
            width: context.screenWidth,
            child: Image.asset(
              'assets/images/girl.jpg',
              height: 250,
              fit: BoxFit.cover,
            ),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: new BackdropFilter(
              filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
              child: new Container(
                decoration: new BoxDecoration(
                    color: Colors.grey.shade200.withOpacity(0.5)),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.all(8),
                child: Column(
                  children: [
                    50.heightBox,
                    'assets/images/girl.jpg'
                        .circularAssetImage(radius: 30)
                        .centered(),
                    10.heightBox,
                    Text(
                      'Jenifer Lawrence',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: kPinkColor),
                    ).shimmer(primaryColor: kPinkColor),
                    5.heightBox,
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('ID : 154545554',style: TextStyle(color: Colors.white),),
                        10.widthBox,
                        Container(
                          padding: EdgeInsets.only(
                              left: 4, right: 4, top: 2, bottom: 2),
                          decoration: BoxDecoration(
                            color: kPinkColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.male,
                                size: 10,
                                color: Colors.white,
                              ),
                              4.widthBox,
                              Text(
                                '20',
                                style: TextStyle(
                                    fontSize: 10, color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    10.heightBox,
                    Text(
                      'Oscar-winning actress Jennifer Lawrence, who is the star of the popular Hunger Games series, is set to steal your hearts with her stunning',
                      style: TextStyle(fontSize: 10),
                      maxLines: 1,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                    ),
                    50.heightBox,
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 8),
                          width: 2,
                          height: 20,
                          color: kPrimaryColor,
                        ),
                        Text(
                          'Level',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16,color: Colors.grey),
                        )
                      ],
                    ),
                    8.heightBox,
                    Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.only(right: 6),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    colors: [
                                      Color(0xFFEEBE8A),
                                      Color(0xFFD23ABD)
                                    ]),
                                borderRadius: BorderRadius.circular(8)),
                            height: 65,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Wealth Level',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                                Text(
                                  '0',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.only(left: 6, right: 6),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    colors: [
                                      Color(0xFFFCCFC4),
                                      Color(0xFF8A46B5)
                                    ]),
                                borderRadius: BorderRadius.circular(8)),
                            height: 65,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Charm Level',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                                Text(
                                  '0',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.only(left: 6, right: 8),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    colors: [
                                  Color(0xFFD1C6F3),
                                  Color(0xFFE8BBAB)
                                ]),
                                borderRadius: BorderRadius.circular(8)),
                            height: 65,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'VIP Level',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                                Text(
                                  '0',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    24.heightBox,
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 8),
                          width: 2,
                          height: 20,
                          color: kPrimaryColor,
                        ),
                        Text(
                          'Family',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16,color: Colors.grey),
                        )
                      ],
                    ),
                    8.heightBox,
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 8),
                          height: 60,
                          width: 60,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              'assets/images/girl.jpg',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Boss Baby'),
                            Text(
                              'ID : 1515145',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        )
                      ],
                    ),
                    24.heightBox,
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 8),
                          width: 2,
                          height: 20,
                          color: kPrimaryColor,
                        ),
                        Text(
                          'Personal Data',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16,color: Colors.grey),
                        )
                      ],
                    ),
                    18.heightBox,
                    Row(
                      children: [
                        Expanded(
                            flex: 1,
                            child: Text(
                              'Language',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 16),
                            )),
                        Expanded(
                            flex: 1,
                            child: Text(
                              'English',
                              style: TextStyle(fontSize: 16),
                            ))
                      ],
                    ),
                    18.heightBox,
                    Row(
                      children: [
                        Expanded(
                            flex: 1,
                            child: Text(
                              'Country',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 16),
                            )),
                        Expanded(
                            flex: 1,
                            child: Text(
                              'India',
                              style: TextStyle(fontSize: 16),
                            ))
                      ],
                    ),
                    18.heightBox,
                    Row(
                      children: [
                        Expanded(
                            flex: 1,
                            child: Text(
                              'D.O.B',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 16),
                            )),
                        Expanded(
                            flex: 1,
                            child: Text(
                              '10-Jul-1993',
                              style: TextStyle(fontSize: 16),
                            ))
                      ],
                    ),
                    16.heightBox,
                    Container(
                      padding: EdgeInsets.only(
                          top: 12, left: 8, right: 8, bottom: 8),
                      width: context.screenWidth,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [kPinkColor, Color(0xFFFFFFFF)]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Gift Received',
                            style: TextStyle(color: Colors.white),
                          ),
                          8.heightBox,
                          GridView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              primary: false,
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 5,
                                      childAspectRatio: 2 / 2),
                              itemCount: 6,
                              itemBuilder: (BuildContext context, int index) {
                                return Card(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset(
                                        'assets/images/girl.jpg',
                                        height: 35,
                                        width: 35,
                                      ),
                                      4.heightBox,
                                      Text('x10')
                                    ],
                                  ),
                                );
                              })
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          SafeArea(child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(onPressed: (){
                Navigator.pop(context);

              }, icon: Icon(Icons.arrow_back)),
              IconButton(onPressed: (){
                Navigator.pushNamed(context, EDIT_PROFILE);
              }, icon: Icon(Icons.edit,color: kPrimaryColor,)),
            ],
          ))

        ],
      ),
    );
  }
}

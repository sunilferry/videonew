import 'package:agora_video_app/Screens/Message/friends_message.dart';
import 'package:agora_video_app/constants.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

import 'company_message.dart';

class Message extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              4.heightBox,
              Container(
                height: 45,
                margin: EdgeInsets.only(left: 16, right: 16),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(
                    5.0,
                  ),
                ),
                child: TabBar(
                  // give the indicator a decoration (color and border radius)
                  indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        5.0,
                      ),
                      gradient: LinearGradient(
                          begin: Alignment.bottomLeft,
                          end: Alignment.topRight,
                          colors: [
                            Colors.purple.shade200.withOpacity(0.5),
                            kPrimaryColor.withOpacity(0.5),
                          ])),
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.black,
                  tabs: [
                    // first tab [you can add an icon using the icon property]
                    Tab(
                      text: 'Message',
                    ),

                    // second tab [you can add an icon using the icon property]
                    Tab(
                      text: 'Friends',
                    ),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [CompanyMessages(), FriendMessages()],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

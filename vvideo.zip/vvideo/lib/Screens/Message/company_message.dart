import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../constants.dart';

class CompanyMessages extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(16),
      child: Column(
        children: [
          getRow('New Followers','22-09 14:16',true),
          16.heightBox,
          getRow('System Message','22-09 14:16',false),
          16.heightBox,
          getRow('V Video Service','22-09 14:16',true),
        ],
      ),
    );
  }


  getRow(String name, String dateTime, bool date1Visibility) {
    return Row(
      children: [
        Container(
            height: 45,
            width: 45,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [kPrimaryColor, kPinkColor]
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            child: Icon(Icons.card_giftcard, color: Colors.white,)),
        10.widthBox,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$name',),
            Visibility(
                visible: date1Visibility,
                child: Text('$dateTime', style: TextStyle(fontSize: 12),))
          ],
        )
      ],
    );
  }
}

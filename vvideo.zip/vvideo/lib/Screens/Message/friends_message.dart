import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';
class FriendMessages extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Flexible(child: TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Search User Name / ID',
                  contentPadding: EdgeInsets.only(left: 8,right: 8),
                  border: OutlineInputBorder(
                  ),

                ),
              )),
              4.widthBox,
              TextButton(onPressed: (){}, child: Text('Search'))
            ],
          ),
          Expanded(

            child: Center(
              child: Text('I have no friends yet.'),
            ),
          )
        ],
      ),
    );
  }
}

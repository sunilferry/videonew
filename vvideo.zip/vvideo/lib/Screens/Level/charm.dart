import 'dart:ui';
import 'package:agora_video_app/constants.dart';

import 'package:percent_indicator/percent_indicator.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:flutter/material.dart';

class Charm extends StatefulWidget {
  @override
  _CharmState createState() => _CharmState();
}

class _CharmState extends State<Charm> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            child: new Stack(
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 75),
                  height:150,
                  width: 150,
                  decoration: BoxDecoration(
                      color:kPinkColor,
                      borderRadius: BorderRadius.circular(80)),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    height: 120,
                    width: 120,
                    decoration: BoxDecoration(
                        color: Color(0xFFC1BC89),
                        borderRadius: BorderRadius.circular(60)),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(24),
                  child: new ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: new BackdropFilter(
                      filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                      child: new Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: new BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.bottomLeft,
                                end: Alignment.topRight,
                                colors: [
                                  Colors.purple.shade200.withOpacity(0.5),
                                  Color(0xFFF3EB9B).withOpacity(0.5),
                                ]),
                            borderRadius: BorderRadius.circular(8)),
                        child: Container(
                          margin: EdgeInsets.all(8),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              'assets/images/girl.jpg'
                                  .circularAssetImage(radius: 30),
                              8.heightBox,
                              Container(
                                padding: EdgeInsets.only(
                                    left: 6, right: 6, top: 3, bottom: 3),
                                decoration: BoxDecoration(
                                  color: kPinkColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Image.asset(
                                      'assets/icons/diamond.png',
                                      height: 8,
                                      width: 8,
                                    ),
                                    4.widthBox,
                                    Text(
                                      '0',
                                      style: TextStyle(
                                          fontSize: 8, color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                              8.heightBox,
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'Current Exp',
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 12),
                                      ),
                                      8.heightBox,
                                      Text(
                                        '500',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'To the next level',
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 12),
                                      ),
                                      8.heightBox,
                                      Text(
                                        '1000',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              10.heightBox,
                              LinearPercentIndicator(
                                percent: 0.5,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text('Charm Level Privileges',style: TextStyle(fontSize: 14),),
          10.heightBox,
          GridView.builder(
              physics: ClampingScrollPhysics(),
              shrinkWrap: true,
              itemCount: 9,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 2.2,
              ),
              itemBuilder: (BuildContext context, int index) {
                return Center(
                  child: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star),
                        Text('Unlock Level 1',style: TextStyle(fontSize: 8,color: Colors.grey),),
                        Text('Level Icon',style: TextStyle(fontSize: 10),),
                      ],
                    ),
                  ),
                );
              }),
          22.heightBox,
          Text('Ways To Level Up',style: TextStyle(fontSize: 14),),

          Container(
            margin: EdgeInsets.only(left: 16,right: 16,top: 10),
            child: Column(
              children: [
                getItem('Gift Received'),
                8.heightBox,
                getItem('Gift Received'),
                8.heightBox,
                getItem('Gift Received'),
                8.heightBox,
                getItem('Gift Received'),
                8.heightBox,
              ],
            ),
          )
        ],
      ),
    );
  }

  getItem(String title){
    return  Row(
      children: [
        Container(

            height: 45,
            width: 45,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [kPrimaryColor,kPinkColor]
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            child: Icon(Icons.card_giftcard,color: Colors.white,)),
        10.widthBox,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$title',style: TextStyle(fontSize: 18),),
            Text('1-Coin = 1-Exp',style: TextStyle(fontSize: 12),)
          ],
        )
      ],
    );
  }
}

import 'package:agora_video_app/Screens/Level/charm.dart';
import 'package:agora_video_app/Screens/Level/wealth.dart';
import 'package:agora_video_app/constants.dart';
import 'package:flutter/material.dart';

class MyLevel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final title = Text(
      'My Levels',
      style: TextStyle(color: Colors.black, fontSize: 14),
    );
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          iconTheme: IconThemeData(color: Colors.black),
          elevation: 0,
          bottom: TabBar(
            tabs: [
              Tab(
                icon: Text(
                  'Wealth',
                  style: TextStyle(color: kPrimaryColor),
                ),
              ),
              Tab(icon: Text('Charm', style: TextStyle(color: kPrimaryColor))),
            ],
          ),
          title:title,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: TabBarView(
          children: [Wealth(), Charm()],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';
class HostVerification extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme:IconThemeData(
          color: Colors.black
        ),
        title: Text('Host Verification',style: TextStyle(color: Colors.black,fontSize: 16),),
      ),
      body: Container(
        margin: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Form(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                decoration: InputDecoration(
                  hintText: '*Your name',
                  labelText: 'Name'
                ),
              ),
              TextFormField(
                decoration: InputDecoration(
                    hintText: '*Mobile number',
                  labelText: 'Mobile',
                  counterText: ''
                ),
                maxLength: 10,
              ),
              8.heightBox,
              Text('*Select your country/region:',style: TextStyle(fontSize: 14),),
              TextFormField(
                readOnly: true,
                decoration: InputDecoration(
                    hintText: '*Select Country',
                  suffixIcon: Icon(Icons.arrow_forward_ios,size: 18,)
                ),
              ),
              8.heightBox,
              Text('*Select your State/UT:',style: TextStyle(fontSize: 14),),
              TextFormField(
                readOnly: true,
                decoration: InputDecoration(
                    hintText: '',
                    suffixIcon: Icon(Icons.arrow_forward_ios,size: 18,)
                ),
              ),
              TextFormField(
                decoration: InputDecoration(
                    hintText: 'Address (optional)',
                  labelText: 'Address'
                ),
              ),
              TextFormField(
                decoration: InputDecoration(
                    hintText: '*Email Address',
                  labelText: 'Email'
                ),
              ),
              TextFormField(
                decoration: InputDecoration(
                    hintText: '*Your National ID Number',
                  labelText: 'National ID'
                ),
              ),
              8.heightBox,
              Text('Application will be rejected if you upload invalid ID#',style: TextStyle(fontSize: 14,color: Colors.red),),
              4.heightBox,
              Container(
                decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(8)
                ),
                width: context.screenWidth,
                height: 150,
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add),
                          10.heightBox,
                          Text('Click to upload national ID image#')
                        ],
                      ),
                    )
                  ],
                ),
              ),
              8.heightBox,
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8)
                ),
                width: context.screenWidth,
                height: 150,
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add),
                          10.heightBox,
                          Text('Click to upload')
                        ],
                      ),
                    )
                  ],
                ),
              ),
              8.heightBox,
              Text('Choose how you want to be paid',style: TextStyle(fontSize: 14),),
              8.heightBox,
              Text('*Select Payment Receival Type:',style: TextStyle(fontSize: 14,color: Colors.grey),),
              4.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                 Row(
                   mainAxisSize: MainAxisSize.min,
                   children: [
                     Radio(
                       value: 1, groupValue: 1, onChanged: (value){},
                     ),
                     10.widthBox,
                     Text('Self')
                   ],
                 ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio(
                        value: 1, groupValue: 1, onChanged: (value){},
                      ),
                      10.widthBox,
                      Text('Via Agency')
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio(
                        value: 1, groupValue: 1, onChanged: (value){},
                      ),
                      10.widthBox,
                      Text('Trusted 3rd Party')
                    ],
                  )
                ],
              ),
              8.heightBox,
              Text('*Select Payment Method:',style: TextStyle(fontSize: 14,color: Colors.grey),),
              4.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio(
                        value: 1, groupValue: 1, onChanged: (value){},
                      ),
                      10.widthBox,
                      Text('Cash')
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio(
                        value: 1, groupValue: 1, onChanged: (value){},
                      ),
                      10.widthBox,
                      Text('Bank')
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio(
                        value: 1, groupValue: 1, onChanged: (value){},
                      ),
                      10.widthBox,
                      Text('Paypal')
                    ],
                  )

                ],
              ),
              8.heightBox,
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Radio(
                    value: 1, groupValue: 1, onChanged: (value){},
                  ),
                  10.widthBox,
                  Text('I want to join V Video Agency')
                ],
              ),

              TextFormField(
                decoration: InputDecoration(
                    hintText: '*Agency ID',
                  labelText: 'Agency ID'
                ),
              ),
              10.heightBox,
              Container(
                  width: context.screenWidth,
                  child: ElevatedButton(onPressed: (){}, child: Text('Apply'))),
              10.heightBox,
            ],
          )),
        ),
      ),
    );
  }
}

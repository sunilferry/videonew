import 'dart:ui';

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:agora_video_app/models/profile_model.dart';
import 'package:agora_video_app/providers/profile_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../config.dart';

class Me extends StatefulWidget {
  @override
  _MeState createState() => _MeState();
}

class _MeState extends BaseStateFull<Me> {
  ProfileResponse? profileModel;
  ProfileProvider? profileProvider;
  Widget rightArrow = Icon(
    Icons.arrow_forward_ios_rounded,
    color: Colors.grey,
    size: 18,
  );

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    profileProvider = Provider.of<ProfileProvider>(context, listen: false);
    getProfile();
  }

  void getProfile() async {
    profileModel = await apiCalls!
        .getProfile(prefManager!.getToken(), prefManager!.getId());
    profileProvider!.changeData(profileModel!);
  }

  Widget frostedWidget(BuildContext context) {
    return Container(
      child: Stack(
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: BoxDecoration(
                color: Colors.yellow, borderRadius: BorderRadius.circular(100)),
          ),
          Positioned(
            right: 0,
            top: 100,
            child: Container(
              height: 120,
              width: 120,
              decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(100)),
            ),
          ),

          Container(
            constraints: BoxConstraints(
                minHeight: context.percentHeight*70
            ),
            child: new ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(16),topRight: Radius.circular(16)),
              child: new BackdropFilter(
                filter: new ImageFilter.blur(sigmaX: 15.0, sigmaY: 15.0),
                child: new Container(
                  decoration: new BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.bottomLeft,
                        end: Alignment.topRight,
                        colors: [
                          Colors.purple.shade200.withOpacity(0.5),
                          Color(0xFFF3EB9B).withOpacity(0.5),
                        ]),
                  ),
                  child:  Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      16.heightBox,
                      Container(
                        margin: EdgeInsets.only(left: 120),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Consumer<ProfileProvider>(builder: (context, profile, child) {
                              return Text(
                                default_name,
                                style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),
                              );
                            }),
                            4.heightBox,
                            Row(children: [
                              Text('ID: 242422',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 14),),
                              8.widthBox,
                              Container(
                                constraints: BoxConstraints(minWidth: 35),
                                padding: EdgeInsets.only(
                                    left: 4, right: 4, top: 2, bottom: 2),
                                decoration: BoxDecoration(
                                  color: kBlueColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Icon(
                                      Icons.male,
                                      size: 12,
                                      color: Colors.white,
                                    ),

                                    Text(
                                      '20',
                                      style: TextStyle(
                                          fontSize: 10, color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                              8.widthBox,
                              Container(
                                constraints: BoxConstraints(minWidth: 35),
                                padding: EdgeInsets.only(
                                    left: 4, right: 4, top: 2, bottom: 2),
                                decoration: BoxDecoration(
                                  color: kPrimaryColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Icon(
                                      Icons.star,
                                      size: 12,
                                      color: Colors.white,
                                    ),

                                    Text(
                                      '17',
                                      style: TextStyle(
                                          fontSize: 10, color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                              8.widthBox,
                              Image.asset('assets/icons/india.png',height: 20,)

                            ],)

                          ],
                        ),
                      ),

                      20.heightBox,
                      Container(
                        height: 60,
                        width: context.screenWidth,
                        margin: EdgeInsets.only(left: 16,right: 16,bottom: 16),
                        child: new ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: new BackdropFilter(
                            filter:
                            new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                            child: new Container(
                              decoration: new BoxDecoration(
                                  color: Colors.grey.shade200.withOpacity(0.5)),
                              child:  Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '0',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            fontSize: 16),
                                      ),
                                      Text(
                                        'Friends',
                                        style: TextStyle(color: Colors.black54),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '0',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            fontSize: 16),
                                      ),
                                      Text(
                                        'Follows',
                                        style: TextStyle(color: Colors.black54),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '0',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            fontSize: 16),
                                      ),
                                      Text(
                                        'Fans',
                                        style: TextStyle(color: Colors.black54),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, WALLET);
                        },
                        child: menu('assets/icons/store.png', 'Wallet'),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, STORE);
                        },
                        child: menu('assets/icons/store.png', 'Store'),
                      ),
                      InkWell(
                        onTap: () {},
                        child: menu('assets/icons/vip.png', 'VIP Center'),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, LEVEL);
                        },
                        child: menu('assets/icons/level.png', 'My Level'),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, SETTING);
                        },
                        child: menu('assets/icons/settings.png', 'Settings'),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, FEEDBACK);
                        },
                        child: menu('assets/icons/settings.png', 'Feedback'),
                      ),
                      16.heightBox,
                    ],
                  ),
                ),
              ),
            ),
          ),

        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: bodyWidget(context),
    );
  }

  Widget bodyWidget(BuildContext context) {
    return SingleChildScrollView(

      child: Stack(
        children: [
          Container(
            constraints: BoxConstraints(
              maxHeight: context.percentHeight*30,
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset('assets/images/girl.jpg',fit:BoxFit.cover,),



                ClipRRect(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(16),topRight: Radius.circular(16)),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
                    child: new Container(
                      color: Colors.grey.withOpacity(0.2),
                    ),
                  ),
                ),

              ],
            ),
          ).onTap(() {
            Navigator.pushNamed(context, VIEW_PROFILE);
          }),

          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(12),topRight: Radius.circular(12))
            ),
            margin: EdgeInsets.only(top: context.percentHeight*28),
            child: frostedWidget(context),
          ),

          Container(
              margin: EdgeInsets.only(top: context.percentHeight*22 ,left: 16),
              child: 'assets/images/girl.jpg'.circularAssetImage(radius: 50))
        ],
      ),
    );
  }

  Widget menu(String iconPath, String title) {
    return Container(
      height: 50,
      margin: EdgeInsets.only(left: 16,right: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Image.asset(
                iconPath,
                height: 20,
                width: 20,
              ),
              16.widthBox,
              Text(title),
            ],
          ),
          rightArrow,
        ],
      ),
    );
  }
}

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:agora_video_app/models/profile_model.dart';
import 'package:agora_video_app/providers/profile_provider.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:velocity_x/velocity_x.dart';

class EditProfileScreen extends StatefulWidget {
  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends BaseStateFull<EditProfileScreen> {
  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final dobCtrl = TextEditingController();
  final bioCtrl = TextEditingController();
  final countryCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  ProfileResponse? profileModel;
  ProfileProvider? profileProvider;

  @override
  void initState() {
    super.initState();

    profileProvider = Provider.of<ProfileProvider>(context, listen: false);
    profileModel = profileProvider!.profileResponse;
    if(profileModel!=null){
      nameCtrl.text = profileModel!.name;
      emailCtrl.text = profileModel!.email;
      print(profileModel!.name);
    }else{

    }
  }

  logOut()async{
    await Future.delayed(const Duration(milliseconds: 100));
    prefManager!.clearPreference();
    Navigator.pushReplacementNamed(context, LOGIN);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Container(
              margin:
                  EdgeInsets.only(left: 24, right: 24, top: 16, bottom: 100),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Edit Profile',
                      style: TextStyle(color: Colors.black, fontSize: 20),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Hero(
                    tag: 'image',
                    child: CircleAvatar(
                      radius: 60,
                      backgroundColor: kPrimaryLightColor,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(60),
                        child: picture == null
                            ? FlutterLogo(
                                size: 80,
                              )
                            : Image.file(
                                picture!,
                                fit: BoxFit.fill,
                                height: 115,
                                width: 115,
                              ),
                      ),
                    ).badge(
                        position: VxBadgePosition.rightBottom,
                        optionalWidget: Icon(
                          Icons.edit_outlined,
                          size: 16,
                        ),
                        size: 30),
                  ).onTap(() {
                    hideKeyboard();
                    showImageOptionDialog(context);
                  }),
                  SizedBox(
                    height: 50,
                  ),
                  Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          TextFormField(
                            controller: nameCtrl,
                            decoration: InputDecoration(
                                hintText: 'Full Name',
                                labelText: 'Full Name',
                                contentPadding: EdgeInsets.all(12),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8))),
                            keyboardType: TextInputType.name,
                            validator: (value) => validate(value),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: emailCtrl,
                            readOnly: true,
                            decoration: InputDecoration(
                                hintText: 'Email',
                                labelText: 'Email',
                                contentPadding: EdgeInsets.all(12),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8))),
                            keyboardType: TextInputType.emailAddress,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: dobCtrl,
                            readOnly: true,
                            decoration: InputDecoration(
                                hintText: 'D.O.B',
                                labelText: 'D.O.B',
                                contentPadding: EdgeInsets.all(12),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8))),
                            onTap: () async {
                              dobCtrl.text = await selectDate('p');
                            },
                            validator: (value) => validate(value),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: bioCtrl,
                            decoration: InputDecoration(
                                hintText: 'Bio',
                                labelText: 'Bio',
                                contentPadding: EdgeInsets.all(12),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8))),
                            validator: (value) => validate(value),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                        ],
                      )),
                  TextField(
                    controller: countryCtrl,
                    readOnly: true,
                    decoration: InputDecoration(
                        hintText: 'Country',
                        labelText: 'Country',
                        contentPadding: EdgeInsets.all(12),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8))),
                    onTap: () async {
                      showCountryPicker(
                        context: context,
                        countryListTheme: CountryListThemeData(flagSize: 24),
                        showPhoneCode: true,
                        // optional. Shows phone code before the country name.
                        onSelect: (Country country) {
                          setState(() {
                            countryCtrl.text = country.name;
                          });
                          print('Select country: ${country.phoneCode}');
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            alignment: Alignment.bottomRight,
            child: Row(
              children: [
                SizedBox(
                  width: 16,
                ),
                Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      onPressed: () {
                        popBack(context);
                      },
                      child: Text(
                        'CANCEL',
                        style: TextStyle(color: Colors.red),
                      ),
                      style: ButtonStyle(
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                              side: BorderSide(color: Colors.red),
                            ),
                          ),
                          backgroundColor:
                              MaterialStateProperty.all(Colors.white)),
                    )),
                SizedBox(
                  width: 50,
                ),
                Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      onPressed: () async {
                        //profileProvider!.changeData();
                        if (_formKey.currentState!.validate()) {
                          final requestParam = {
                            "name": nameCtrl.text,
                            "gender": "male",
                            "accountId": "279398h8h9h",
                            "deviceId": await getDeviceId(),
                            "profilePicAddress": "34",
                            "ipAddress": await getIpAddress(),
                          };
                          print(requestParam);
                          //apiCalls!.updateProfile(requestParam, prefManager!.getToken(),prefManager!.getId());
                        }
                      },
                      child: Text('SAVE'),
                      style: ButtonStyle(
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25)),
                          ),
                          backgroundColor:
                              MaterialStateProperty.all(kPrimaryColor)),
                    )),
                SizedBox(
                  width: 16,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

import 'package:agora_video_app/Screens/Signup/components/or_divider.dart';
import 'package:agora_video_app/Screens/Signup/components/social_icon.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:agora_video_app/helpers/extensions/double_extension.dart';
import 'package:agora_video_app/helpers/extensions/string_extenstion.dart';
import 'package:agora_video_app/helpers/widgets/frosted_Input_box.dart';
import 'package:agora_video_app/helpers/widgets/frosted_widget.dart';
import 'package:agora_video_app/helpers/widgets/primary_gradient_btn.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Body extends StatefulWidget {
  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends BaseStateFull<Body> {
  String email = '';
  String password = '';

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              fit: BoxFit.cover,
              image: AssetImage('assets/images/girl_bg_img.png'))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          FrostedWidget(
            width: Get.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                'Login'.text(
                  size: 18,
                ),
                24.height,
                'Enter Mobile No.'.text(size: 16),
                8.height,
                FrostedInputBox(
                  hint: 'Mobile',
                  prefixIcon: Icon(Icons.call,color: Colors.white,),
                ),
                16.height,
                'Password'.text(size: 16),
                8.height,
                FrostedInputBox(
                  hint: 'Password',
                  prefixIcon: Icon(Icons.lock_outlined,color: Colors.white,),
                ),
                8.height,
                Align(
                    alignment: Alignment.topRight,
                    child: 'Forgot Password?'.text(size: 14)),
                32.height,

                Align(
                  alignment: Alignment.center,
                  child: PrimaryGradientBtn(
                    onTap: () {
                      Navigator.pushReplacementNamed(context, HOME);
                    },
                    child: 'Login'.text(size: 16),
                    width: 162,
                  ),
                ),
                SizedBox(height: size.height * 0.03),
                Align(alignment: Alignment.center, child: OrDivider()),
                12.height,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SocalIcon(
                      key: Key('ertfdggc'),
                      iconSrc: "assets/images/google_img.png",
                      press: () {},
                    ),
                    12.width,
                    SocalIcon(
                      iconSrc: "assets/images/insta_img.png",
                      press: () {},
                      key: Key('nhbvnb'),
                    ),
                    12.width,
                    SocalIcon(
                      iconSrc: "assets/images/facebook_img.png",
                      press: () {},
                      key: Key('etsx'),
                    ),
                  ],
                ),
                24.height,
              ],
            ),
          )
        ],
      ),
    );
  }
}

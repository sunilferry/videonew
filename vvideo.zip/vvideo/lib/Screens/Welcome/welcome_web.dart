import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class WelcomeWeb extends StatefulWidget {
  @override
  _WelcomeWebState createState() => _WelcomeWebState();
}

class _WelcomeWebState extends State<WelcomeWeb> {
  bool loginVisiblity = true,
      createVisibility = false,
      welcomeVisibility = false,
      heloVisibility = true;



  @override
  Widget build(BuildContext context) {
    double right = 1000;
    return Stack(
      children: [
        Visibility(visible: welcomeVisibility, child: welcomeBack(context)),
        Visibility(
            visible: createVisibility,
            child: Align(
                alignment: Alignment.topRight, child: createAccount(context))),
        Visibility(visible: loginVisiblity, child: loginPage(context)),
        Visibility(
          visible: heloVisibility,
          child: Align(
            alignment: Alignment.topRight,
            child: helloPage(context),
          ),
        ),
        Container(
          margin: EdgeInsets.all(16),
          child: Row(
            children: [
              Image.asset(
                'assets/icons/logo.png',
                height: 40,
              ),
              10.widthBox,
              Text(
                'V Video',
                style: TextStyle(
                    color: Colors.pink,
                    fontWeight: FontWeight.bold,
                    fontSize: 25),
              ),
              30.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'Home',
                    style: TextStyle(color: Colors.black),
                  )),
              20.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'About',
                    style: TextStyle(color: Colors.black),
                  )),
              20.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'Events',
                    style: TextStyle(color: Colors.black),
                  )),
              20.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'Privacy Policy',
                    style: TextStyle(color: Colors.black),
                  )),
              20.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'Term & Conditions',
                    style: TextStyle(color: Colors.black),
                  )),
              20.widthBox,
              TextButton(
                  onPressed: () {},
                  child: Text(
                    'Contact',
                    style: TextStyle(color: Colors.black),
                  )),
            ],
          ),
        )
      ],
    );
  }

  Widget welcomeBack(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: new AssetImage("assets/images/web_login_bg.jpg"),
          fit: BoxFit.cover,
        ),
      ),
      width: context.percentWidth * 35,
      height: context.screenHeight,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Welcome Back!',
            style: TextStyle(fontSize: 35, color: Colors.white),
          ),
          20.heightBox,
          Text(
            'To keep connected with us please \n login with your personal info.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white),
          ),
          20.heightBox,
          Container(
            height: 45,
            width: context.percentWidth * 10,
            child: ElevatedButton(
              onPressed: () {
                createVisibility = false;
                welcomeVisibility = false;
                loginVisiblity = true;
                heloVisibility = true;
                setState(() {});
              },
              child: Text('SIGN IN'),
              style: ButtonStyle(
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.percentWidth * 8),
                  side: BorderSide(color: Colors.white),
                )),
                backgroundColor: MaterialStateProperty.all(Colors.pinkAccent),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget helloPage(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: new AssetImage("assets/images/web_login_bg.jpg"),
          fit: BoxFit.cover,
        ),
      ),
      width: context.percentWidth * 35,
      height: context.screenHeight,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Hello, Friends!',
            style: TextStyle(fontSize: 35, color: Colors.white),
          ),
          20.heightBox,
          Text(
            'Enter your personal details\nand start journey with us',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white),
          ),
          20.heightBox,
          Container(
            height: 45,
            width: context.percentWidth * 10,
            child: ElevatedButton(
              onPressed: () {
                createVisibility = true;
                welcomeVisibility = true;
                loginVisiblity = false;
                heloVisibility = false;
                setState(() {});
              },
              child: Text('SIGN UP'),
              style: ButtonStyle(
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.percentWidth * 8),
                  side: BorderSide(color: Colors.white),
                )),
                backgroundColor: MaterialStateProperty.all(Colors.pinkAccent),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget createAccount(BuildContext context) {
    return Container(
      width: context.percentWidth * 65,
      height: context.screenHeight,
      color: Color(0xFFF9ECF0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Create Account',
            style: TextStyle(
                fontSize: 35,
                color: Colors.pinkAccent,
                fontWeight: FontWeight.bold),
          ),
          30.heightBox,
          Container(
            width: context.percentWidth * 30,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                ),
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                ),
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                )
              ],
            ),
          ),
          50.heightBox,
          Text('or use your email for registration'),
          30.heightBox,
          Container(
            width: context.percentWidth * 35,
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                      fillColor: Colors.grey,
                      hintText: 'Name',
                      border: OutlineInputBorder()),
                ),
                30.heightBox,
                TextField(
                  decoration: InputDecoration(
                      fillColor: Colors.grey,
                      hintText: 'Email',
                      border: OutlineInputBorder()),
                ),
                30.heightBox,
                TextField(
                  decoration: InputDecoration(
                      fillColor: Colors.grey,
                      hintText: 'Password',
                      border: OutlineInputBorder()),
                ),
              ],
            ),
          ),
          50.heightBox,
          Container(
            height: 45,
            width: context.percentWidth * 15,
            child: ElevatedButton(
              onPressed: () {},
              child: Text('SIGN UP'),
              style: ButtonStyle(
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.percentWidth * 8),
                )),
                backgroundColor: MaterialStateProperty.all(Colors.pinkAccent),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget loginPage(BuildContext context) {
    return Container(
      width: context.percentWidth * 65,
      height: context.screenHeight,
      color: Color(0xFFF9ECF0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Sign in to V Video',
            style: TextStyle(
                fontSize: 35,
                color: Colors.pinkAccent,
                fontWeight: FontWeight.bold),
          ),
          30.heightBox,
          Container(
            width: context.percentWidth * 30,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                ),
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                ),
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.purple)),
                  child: Icon(Icons.facebook),
                )
              ],
            ),
          ),
          50.heightBox,
          Text('or use your email email'),
          30.heightBox,
          Container(
            width: context.percentWidth * 35,
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                      fillColor: Colors.grey,
                      hintText: 'Email',
                      border: OutlineInputBorder()),
                ),
                30.heightBox,
                TextField(
                  decoration: InputDecoration(
                      fillColor: Colors.grey,
                      hintText: 'Password',
                      border: OutlineInputBorder()),
                ),
                20.heightBox,
                TextButton(
                    onPressed: () {}, child: Text('Forgot your password?'))
              ],
            ),
          ),
          50.heightBox,
          Container(
            height: 45,
            width: context.percentWidth * 15,
            child: ElevatedButton(
              onPressed: () {},
              child: Text('SIGN IN'),
              style: ButtonStyle(
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.percentWidth * 8),
                )),
                backgroundColor: MaterialStateProperty.all(Colors.pinkAccent),
              ),
            ),
          )
        ],
      ),
    );
  }
}

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:agora_video_app/helpers/extensions/double_extension.dart';
import 'package:agora_video_app/helpers/extensions/hex_color.dart';
import 'package:agora_video_app/helpers/extensions/string_extenstion.dart';
import 'package:agora_video_app/helpers/widgets/frosted_widget.dart';
import 'package:agora_video_app/helpers/widgets/primary_gradient_btn.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              fit: BoxFit.cover,
              image: AssetImage('assets/images/girl_bg_img.png'))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          FrostedWidget(
              height: 216,
              width: Get.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  'Let’s\nConnect Together'.text(fontWeight: FontWeight.w800,size: 24),
                  32.height,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [

                      PrimaryGradientBtn(onTap: (){
                        Navigator.pushNamed(context, LOGIN);
                      },
                        child:  'Login'.text(size: 16),
                      width: 162,
                      ),

                      GestureDetector(
                        onTap: () {
                          Navigator.pushNamed(context, SIGNUP);
                        },
                        child: Container(
                          height: 48,
                          width: 162,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: HexColor('#ED2894')),
                             ),
                          child: Center(child: 'Sign UP'.text(size: 16,color: HexColor('#ED2894'))),
                        ),
                      ),

                    ],
                  )
                ],
              )),
        ],
      ),
    );
  }
}

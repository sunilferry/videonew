import 'package:agora_video_app/Screens/Welcome/components/body.dart';
import 'package:agora_video_app/Screens/Welcome/welcome_web.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends BaseStateFull<WelcomeScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    return Material(
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints){
          if (constraints.maxWidth > 600) {
            return WelcomeWeb();
          } else {
            return Body();
          }
        },
      ),
    );
  }
}

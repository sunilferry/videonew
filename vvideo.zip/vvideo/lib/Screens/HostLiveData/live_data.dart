import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:velocity_x/velocity_x.dart';

import '../../constants.dart';

class LiveData extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Color(0xCD0DA8)));
    return Material(
      child: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
              Color(0xFFF7BBBB),
              Color(0xFFF5E5E5),
              Color(0xFFF5E5E5)
            ])),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            iconTheme: IconThemeData(color: Colors.black),
            title: Text(
              'Live Data',
              style: TextStyle(color: Colors.black),
            ),
          ),
          body: Container(
            margin: EdgeInsets.all(16),
            child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(left: 8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              bottomLeft: Radius.circular(8)),
                          gradient: LinearGradient(
                              colors: [kPinkColor, Color(0xFFF0D3F5)])),
                      height: 120,
                      width: context.percentWidth * 50,
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          'Sunil verma',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    Container(

                      height: 120,
                      width: context.screenWidth,
                      margin: EdgeInsets.only(left: 60),
                      child: new ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: new BackdropFilter(
                          filter:
                              new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                          child: new Container(
                            decoration: new BoxDecoration(
                                color: Colors.grey.shade200.withOpacity(0.5)),
                            child: Text('Hello'),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                20.heightBox,
                Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(left: 8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              bottomLeft: Radius.circular(8)),
                          gradient: LinearGradient(
                              colors: [kPinkColor, Color(0xFFF0D3F5)])),
                      height: 120,
                      width: context.percentWidth * 50,
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          'Sunil verma',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    Container(
                      height: 120,
                      width: context.screenWidth,
                      margin: EdgeInsets.only(left: 60),
                      child: new ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: new BackdropFilter(
                          filter:
                              new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                          child: new Container(
                            decoration: new BoxDecoration(
                                color: Colors.grey.shade200.withOpacity(0.5)),
                            child: Text('Hello'),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

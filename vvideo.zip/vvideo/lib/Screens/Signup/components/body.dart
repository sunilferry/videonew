import 'package:agora_video_app/Screens/Signup/components/background.dart';
import 'package:agora_video_app/components/already_have_an_account_acheck.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:agora_video_app/models/register_reponse.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:velocity_x/velocity_x.dart';
import '../../../constants.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends BaseStateFull<Body> {
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      key: Key('hfghgfj'),
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(32),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                50.heightBox,

                Center(
                  child: Lottie.asset(
                    "assets/json_files/signup.json",
                    height: size.height * 0.30,
                  ),
                ),
                Text(
                  "SIGNUP",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                24.heightBox,
                TextFormField(
                  controller: nameController,

                  decoration: InputDecoration(
                    hintText: 'Full Name',
                    labelText: "Full Name",
                    prefixIcon: Icon(Icons.person_outline),
                    border: OutlineInputBorder(
                    ),
                      contentPadding: EdgeInsets.only(left: 8,right: 8)
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Can\'t be empty';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 8,
                ),
                TextFormField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: "Email",
                    prefixIcon: Icon(Icons.email_outlined),
                    hintText: 'Your Email',
                    border: OutlineInputBorder(
                    ),
                      contentPadding: EdgeInsets.only(left: 8,right: 8)
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Can\'t be empty';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 8,
                ),
                TextFormField(
                  controller: passwordController,
                  decoration: InputDecoration(
                    labelText: "Password",
                    prefixIcon: Icon(Icons.lock_outlined),
                    hintText: 'Password',
                    border: OutlineInputBorder(
                        ),
                    contentPadding: EdgeInsets.only(left: 8,right: 8)
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Can\'t be empty';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height:45,
                  width: MediaQuery.of(context).size.width,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                        ),
                        backgroundColor:
                            MaterialStateProperty.all(kPrimaryColor)),
                    onPressed: () async {
                      if (formKey.currentState!.validate()) {
                        showLoader();
                        final requestParam = {
                          "name": nameController.text,
                          "email": emailController.text,
                          "password": passwordController.text,
                          "gender": "Male",
                          "dob": "2000-01-01",
                          "deviceId": await getDeviceId(),
                          "accountId": await getDeviceId(),
                          "ipAddress": await getIpAddress(),
                        };
                        RegisterResponse? response =
                            await apiCalls!.register(requestParam);
                        hideLoader();
                        if (response != null) {
                          prefManager!.setEmail(response.user.email);
                          prefManager!.setId(response.user.id);
                          prefManager!.setName(response.user.name);
                          prefManager!.setToken(response.tokens.access.token);
                          Navigator.pushReplacementNamed(context, HOME);
                        } else {
                          showMessage('Something wrong');
                        }
                      }
                    },
                    child: Text('SIGNUP'),
                  ),
                ),
                SizedBox(height: size.height * 0.03),
                AlreadyHaveAnAccountCheck(
                  key: Key('nmdfdfdgjhgj'),
                  login: false,
                  onTap: () {
                    print('sdfsdf');
                    Navigator.pushReplacementNamed(context, LOGIN);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

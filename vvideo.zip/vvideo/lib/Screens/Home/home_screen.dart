import 'package:agora_video_app/Screens/Explore/explore.dart';
import 'package:agora_video_app/Screens/Me/me.dart';
import 'package:agora_video_app/Screens/Message/message.dart';
import 'package:agora_video_app/Screens/Party/party.dart';
import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lottie/lottie.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int page = 0;
  PageController? pageController;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: PageView(
          physics: NeverScrollableScrollPhysics(),
          children: <Widget>[Party(),Explore(),Message(),Me()],
          controller: pageController,
          onPageChanged: onPageChanged,
        ),
        floatingActionButton: GestureDetector(
            onTap: () {
              Navigator.pushNamed(context, BROADCASTER);
            },
            child: Lottie.asset('assets/json_files/live.json',
                height: 55, width: 55)),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: BottomAppBar(
          shape: CircularNotchedRectangle(),
          child: Container(
            height: 55,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () {
                    onTap(0);
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset('assets/icons/home.svg',height: 24,width: 24,),
                      Text(
                        'Home',
                        style: TextStyle(color: getColor(0)),
                      )
                    ],
                  ),
                ),

                GestureDetector(
                  onTap: () {
                    onTap(1);
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.explore_outlined,
                        color: getColor(1),
                      ),
                      Text(
                        'Explore',
                        style: TextStyle(color: getColor(1)),
                      )
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    onTap(2);
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.message,
                        color: getColor(2),
                      ),
                      Text(
                        'Message',
                        style: TextStyle(color: getColor(2)),
                      )
                    ],
                  ),
                ),GestureDetector(
                  onTap: () {
                    onTap(3);
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.more_horiz,
                        color: getColor(3),
                      ),
                      Text(
                        'More',
                        style: TextStyle(color: getColor(3)),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Color(0xCD0DA8)));
    pageController = PageController(initialPage: this.page);
  }

  @override
  void dispose() {
    pageController!.dispose();
    super.dispose();
  }

  void onTap(int index) {
    pageController!.jumpToPage(index);
  }

  void onPageChanged(int page) {
    setState(() {
      this.page = page;
    });
  }

  Color getColor(int value) {
    return this.page == value ? kPrimaryColor : Color(0XFFBBBBBB);
  }
}

import 'dart:ui';

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/app_routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class Wallet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Stack(
        children: <Widget>[
          Container(
            height: 300,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF9065F7), kPinkColor])),
          ),
          Container(
            margin: EdgeInsets.only(top: 280),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24))),
          ),
          Column(
            children: [
              SafeArea(
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        )),
                    Text(
                      'Wallet',
                      style: TextStyle(color: Colors.white),
                    )
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.purple.withOpacity(0.4),
                      spreadRadius: 10,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                margin: EdgeInsets.only(left: 24, right: 24, top: 100),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 5.0),
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      height: 200.0,
                      decoration: new BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.purple.shade200.withOpacity(0.5),
                                Color(0xFFF3EB9B).withOpacity(0.5),
                              ]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Container(

                        child: Stack(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16,right: 16,bottom: 60),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        'VISA',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white,
                                            fontStyle: FontStyle.italic),
                                      )
                                    ],
                                  ),
                                  Text(
                                    '9524 4587 5645 4582',
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        '05/22',
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            color: Colors.black12,
                                            borderRadius: BorderRadius.circular(6)),
                                        padding: EdgeInsets.only(
                                            left: 8, right: 8, top: 8, bottom: 8),
                                        child: Text(
                                          'Show CVV',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white),
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                padding: EdgeInsets.only(left: 16,top: 16),
                                height: 50,
                                width: context.screenWidth,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [kPrimaryColor,kPinkColor]
                                  )
                                ),
                                child: Text("Sunil verma",style: TextStyle(color: Colors.white),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(24),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: new BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.purple.shade200.withOpacity(0.5),
                                kBlueColor.withOpacity(0.5),
                              ]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Container(
                        padding: EdgeInsets.only(top: 4, bottom: 4),
                        margin: EdgeInsets.all(8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Image.asset(
                                      'assets/icons/diamond.png',
                                      height: 25,
                                      width: 25,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text('Diamond')
                                  ],
                                ),
                                Text(
                                  'Exchange diamond to coin.',
                                  style: TextStyle(fontSize: 10),
                                )
                              ],
                            ),
                            Text('0'),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ).onTap(() {
                Navigator.pushNamed(context, CONVERT_DIAMOND);
              }),
              Container(
                margin: EdgeInsets.only(left: 24, right: 24),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: new BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.purple.shade200.withOpacity(0.5),
                                kBlueColor.withOpacity(0.5),
                              ]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Container(
                        padding: EdgeInsets.only(top: 4, bottom: 4),
                        margin: EdgeInsets.all(8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  'assets/icons/razorpay.png',
                                  height: 25,
                                  width: 25,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text('Razor Pay')
                              ],
                            ),
                            Text(
                              'Purchase coin with Razorpay',
                              style: TextStyle(fontSize: 10),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ).onTap(() {
                showModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    barrierColor: Colors.transparent,
                    context: context,
                    builder: (BuildContext context) {
                      return giftSheet(context);
                    });
              }),
              Container(
                margin: EdgeInsets.only(left: 24, right: 24, top: 24),
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: new BackdropFilter(
                    filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: new BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.purple.shade200.withOpacity(0.5),
                                kBlueColor.withOpacity(0.5),
                              ]),
                          borderRadius: BorderRadius.circular(8)),
                      child: Container(
                        padding: EdgeInsets.only(top: 4, bottom: 4),
                        margin: EdgeInsets.all(8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  'assets/icons/gpay.png',
                                  height: 25,
                                  width: 25,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text('In App Purchase')
                              ],
                            ),
                            Text(
                              'Purchase coin with In App Purchase',
                              style: TextStyle(fontSize: 10),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ).onTap(() {
                showModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    barrierColor: Colors.transparent,
                    context: context,
                    builder: (BuildContext context) {
                      return giftSheet(context);
                    });
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget giftSheet(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(6),
      child: new ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: new BackdropFilter(
          filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
          child: new Container(
              width: context.screenWidth,
              decoration: new BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        Colors.purple.shade200.withOpacity(0.5),
                        Color(0xFFF3EB9B).withOpacity(0.5),
                      ]),
                  borderRadius: BorderRadius.circular(8)),
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: 6,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                      height: 50,
                      margin: EdgeInsets.all(8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Image.asset('assets/icons/diamond.png'),
                              16.widthBox,
                              Text('250')
                            ],
                          ),
                          ElevatedButton(
                              onPressed: () {}, child: Text('\u20b9199'))
                        ],
                      ),
                    );
                  })),
        ),
      ),
    );
  }
}

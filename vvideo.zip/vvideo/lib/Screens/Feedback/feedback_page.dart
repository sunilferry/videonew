import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class FeedbackPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Text('Top up'),
                        style: OutlinedButton.styleFrom(
                          shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                    8.widthBox,
                    Expanded(
                      flex: 1,
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Text('App Error'),
                        style: OutlinedButton.styleFrom(
                          shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                20.heightBox,
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Text('Suggestion'),
                        style: OutlinedButton.styleFrom(
                          shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                    8.widthBox,
                    Expanded(
                      flex: 1,
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Text('Earning Info'),
                        style: OutlinedButton.styleFrom(
                          shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                20.heightBox,
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Text('Suggestion'),
                        style: OutlinedButton.styleFrom(
                          shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                    8.widthBox,
                    Expanded(
                      flex: 1,
                      child: Text(''),
                    ),
                  ],
                ),
                30.heightBox,
                Text('Choose your contact information'),
                20.heightBox,
                Row(
                  children: [
                    Icon(Icons.radio_button_off),
                    10.widthBox,
                    Text('Email'),
                  ],
                ),
                10.heightBox,
                Row(
                  children: [
                    Icon(
                      Icons.radio_button_on,
                      color: Colors.purple,
                    ),
                    10.widthBox,
                    Text('Mobile'),
                  ],
                ),
                20.heightBox,
                TextField(
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter mobile number',
                  contentPadding: EdgeInsets.only(left: 8,right: 8)
                  ),
                ),
                16.heightBox,
                Text(
                  'Explain your issue in detail? If it is a bug, please guide us so we will be able to reproduce and test the issue.',
                  style: TextStyle(fontSize: 10),
                ),
                10.heightBox,
                TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.all( 8)
                  ),
                  keyboardType: TextInputType.multiline,
                  maxLines: 5,
                ),
                20.heightBox,
                Text('Upload Picture/Video'),
                20.heightBox,
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8)
                  ),
                  child: Center(
                    child: Icon(Icons.add),
                  ),
                ),
                60.heightBox,

              ],
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            margin: EdgeInsets.all(24),
            width: context.screenWidth,
            child: ElevatedButton(
              onPressed: () {},
              child: Text('Submit'),
            ),
          ),
        ),
      ],
    );
  }
}

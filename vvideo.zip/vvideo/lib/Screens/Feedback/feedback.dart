import 'package:agora_video_app/Screens/Feedback/feedback_page.dart';
import 'package:agora_video_app/Screens/Feedback/my_feedback_page.dart';
import 'package:flutter/material.dart';

class FeedBack extends StatefulWidget {
  @override
  _FeedBackState createState() => _FeedBackState();
}

class _FeedBackState extends State<FeedBack> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          iconTheme: IconThemeData(color: Colors.black),
          elevation: 0,
          title: Text(
            'Feedback',
            style: TextStyle(color: Colors.black, fontSize: 16),
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: SafeArea(
          child: Column(
            children: [
              Container(
                height: 45,
                margin: EdgeInsets.only(left: 24, right: 24),
                child: TabBar(
                  labelColor: Colors.deepPurple,
                  unselectedLabelColor: Colors.grey,
                  tabs: [
                    Tab(
                      text: 'Feedback',
                    ),
                    Tab(
                      text: 'My Feedback',
                    ),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [FeedbackPage(), MyFeedback()],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
class MyFeedback extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Coming soon.....',style: TextStyle(fontSize: 25),),
    );
  }
}

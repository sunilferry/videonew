import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
class Splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);
    return Material(
      color: Colors.white,
      child: Center(
        child: Lottie.asset('assets/json_files/logo.json',height: 150,width: 150),

      ),
    );
  }
}

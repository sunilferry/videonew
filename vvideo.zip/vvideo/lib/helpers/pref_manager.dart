import 'package:shared_preferences/shared_preferences.dart';

class PrefManager {
  static late SharedPreferences prefs;
  static PrefManager? prefManager;


  static Future<PrefManager> getInstance() async {

    prefs = await SharedPreferences.getInstance();
    if(prefManager==null){
      prefManager=PrefManager();
    }
    return prefManager!;
  }



  dynamic setEmail(String email) async {
    return prefs.setString('email', email);
  }

  String getEmail() {
    return prefs.getString('email') ?? '';
  }

  dynamic setId(String id) async {
    return prefs.setString('id', id);
  }

  String getId() {
    return prefs.getString('id') ?? '';
  }

  dynamic setOfficeId(int officeId) async {
    return prefs.setInt('officeId', officeId);
  }

  int getOfficeId() {
    return prefs.getInt('officeId') ?? 0;
  }

  dynamic setName(String name) async {
    return prefs.setString('name', name);
  }

  String getName() {
    return prefs.getString('name') ?? '';
  }

  dynamic setMobile(String mobile) async {
    return prefs.setString('mobile', mobile);
  }

  String getMobile() {
    return prefs.getString('mobile') ?? '';
  }

  dynamic setToken(String token) async {
    return prefs.setString('token', token);
  }

  String getToken() {
    return prefs.getString('token') ?? '';
  }



  dynamic setIsEmailPopped(bool isEmailPopped) async {
    return prefs.setBool('isEmailPopped', isEmailPopped);
  }

  bool getIsEmailPopped()  {
    return prefs.getBool('isEmailPopped') ?? false;
  }

  clearPreference(){
    prefs.clear();
  }

}

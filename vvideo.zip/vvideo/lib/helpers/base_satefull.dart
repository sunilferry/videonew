import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/pref_manager.dart';
import 'package:agora_video_app/networking/ApiCalls.dart';
import 'package:connectivity/connectivity.dart';
import 'package:crypto/crypto.dart';
import 'package:dart_ipify/dart_ipify.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:image_picker/image_picker.dart';
import 'package:platform_device_id/platform_device_id.dart';
import 'package:socket_io_client/socket_io_client.dart';

abstract class BaseStateFull<T extends StatefulWidget> extends State<T> {
  Socket? socket;
  late final connectivity;

  PrefManager? prefManager;
  ApiCalls? apiCalls;
  late DateTime currentDate;
  final regexp = RegExp(
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");

  @override
  void initState() {
    super.initState();
    _init();
    checkConnectivity();
  }

  _init() {
    if (prefManager == null) {
      print('initiated');
      prefManager = PrefManager();

      apiCalls = ApiCalls();
    }

    if (socket == null) {
      socket = io(
          'http://localhost:3000',
          OptionBuilder()
              .setTransports(['websocket']) // for Flutter or Dart VM
              .disableAutoConnect() // disable auto-connection
              .setExtraHeaders({'foo': 'bar'}) // optional
              .build());
    }
  }

  connect() {
    socket!.connect();
  }

  disconnect() {
    socket!.disconnect();
  }

  Future<String?> getDeviceId() async {
    return await PlatformDeviceId.getDeviceId;
  }

  Future<String?> getIpAddress() async {
    return await Ipify.ipv64();
  }

  validate(String? value) {
    if (value!.isEmpty) {
      return 'Can\'t be empty';
    }
    return null;
  }

  hideKeyboard() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  Future<String> selectDate(String type) async {
    currentDate = new DateTime.now();
    final DateTime? pickedDate = await showDatePicker(
        helpText: 'Select Your Date of Birth',
        confirmText: 'Confirm',
        context: context,
        initialDate: currentDate,
        firstDate: type == 'p'
            ? DateTime(2015)
            : type == 'o'
                ? DateTime(2015)
                : DateTime.now(),
        lastDate: type == 'f'
            ? DateTime(2050)
            : type == 'o'
                ? DateTime(2050)
                : DateTime.now());
    if (pickedDate != null && pickedDate != currentDate)
      currentDate = pickedDate;
    String day = currentDate.day.toString();
    String month = currentDate.month.toString();
    day = day.length == 1 ? '0$day' : day;
    month = month.length == 1 ? '0$month' : month;
    return '$day/$month/${currentDate.year}';
  }

  void checkConnectivity() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
    } else if (connectivityResult == ConnectivityResult.wifi) {}
    print(connectivityResult);
  }

  void showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  popBack(BuildContext context) {
    Navigator.pop(context);
  }

  String encrypt(String input) {
    return md5.convert(utf8.encode(input)).toString();
  }

  showImageOptionDialog(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.only(top: 5.0, left: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Pick Image'),
                    Center(
                        child: IconButton(
                      onPressed: () {
                        popBack(context);
                      },
                      icon: Icon(Icons.close),
                    ))
                  ],
                ),
              ),
              TextButton(
                  onPressed: () {
                    popBack(context);
                    _pickImage('');
                  },
                  child: Row(
                    children: [
                      Icon(Icons.camera, color: kPrimaryColor),
                      SizedBox(
                        width: 16,
                      ),
                      Text('Camera', style: TextStyle(color: kPrimaryColor)),
                    ],
                  )),
              TextButton(
                  onPressed: () {
                    popBack(context);
                    _pickImage('gallery');
                  },
                  child: Row(
                    children: [
                      Icon(Icons.image, color: kPrimaryColor),
                      SizedBox(
                        width: 16,
                      ),
                      Text(
                        'Gallery',
                        style: TextStyle(color: kPrimaryColor),
                      ),
                    ],
                  )),
              SizedBox(
                height: 16,
              ),
            ],
          ),
        );
      },
    );
  }

  String imageBase64 = '', imagePath = 'No Image Chosen';
  File? picture;

  _pickImage(String source) async {
    final ImagePicker _picker = ImagePicker();
    // Pick an image
    final XFile? image = await _picker.pickImage(
        source: source == 'gallery' ? ImageSource.gallery : ImageSource.camera);
    if (image != null) {
      imagePath = image.path;
      picture = File(imagePath);
      List<int> imageBytes = picture!.readAsBytesSync();
      imageBase64 = base64Encode(imageBytes);
      setState(() {});
      print(imagePath);
    }
  }

  showAlertDialog(BuildContext context, String id, String type) {
    Widget confirm = ElevatedButton(
        onPressed: () async {
          popBack(context);
          onAlertConfirmClick(id, type);
        },
        child: Text('Confirm'));
    Widget cancel = TextButton(
        onPressed: () {
          popBack(context);
        },
        child: Text('Cancel'));
    AlertDialog alertDialog = AlertDialog(
      title: Text('Alert'),
      content: Text('Confirm to delete...'),
      actions: [cancel, confirm],
    );
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return alertDialog;
      },
    );
  }

  onAlertConfirmClick(String id, String type) {}

  showLoader() {
    Loader.show(context, progressIndicator: CircularProgressIndicator());
  }

  hideLoader() {
    Loader.hide();
  }
}

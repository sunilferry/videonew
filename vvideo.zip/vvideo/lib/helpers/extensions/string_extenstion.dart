
import 'package:flutter/material.dart';
extension StringExtension on String{
  Widget text({double size=16,Color color=Colors.white,FontWeight? fontWeight})=>Text(this,style: TextStyle(fontSize: size,fontWeight: fontWeight,color:color),);
}
/**
 *Developed by Suneel kumar 27-01-2022
 */

import 'package:flutter/material.dart';
extension DoubleExt on int{
  Widget get  height=>SizedBox(height: toDouble(),);
  Widget get  width=>SizedBox(width: toDouble(),);
}
/**
 *Developed by Suneel kumar 27-01-2022
 */
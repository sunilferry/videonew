import 'package:flutter/material.dart';

abstract class BaseStateLess extends StatelessWidget {


  void showMessage(String msg,BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

}

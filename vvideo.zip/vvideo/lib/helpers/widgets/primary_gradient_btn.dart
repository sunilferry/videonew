import 'package:agora_video_app/helpers/extensions/hex_color.dart';
import 'package:flutter/material.dart';
/**
 *Developed by Suneel kumar 27-01-2022
 */

class PrimaryGradientBtn extends StatelessWidget {
  GestureTapCallback? onTap;
  Widget? child;
  double? width=162;

  PrimaryGradientBtn({this.onTap, this.child, this.width});

  @override
  Widget build(BuildContext context) {
    return  GestureDetector(
      onTap: onTap,
      child: Container(
        height: 48,
        width: width,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: RadialGradient(
                radius: 1.2,
                colors: [
                  HexColor('#ED2894'),
                  HexColor('#CF0B63'),
                ])),
        child: Center(child: child),
      ),
    );
  }
}

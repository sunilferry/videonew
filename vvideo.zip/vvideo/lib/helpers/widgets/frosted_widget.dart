import 'dart:ui';

import 'package:flutter/material.dart';
/**
 *Developed by Suneel kumar 27-01-2022
 */


class FrostedWidget extends StatelessWidget {
  Widget child;
  double? width;
  double? height;

  FrostedWidget({required this.child,this.width,this.height});

  @override
  Widget build(BuildContext context) {
    return  ClipRRect(
      borderRadius: BorderRadius.only(topLeft: Radius.circular(25),topRight: Radius.circular(25)),
      child:  BackdropFilter(
        filter:  ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
        child:  Container(
          padding: EdgeInsets.all(24),
          width: width,
          height: height,
          decoration: new BoxDecoration(
              color: Colors.grey.shade200.withOpacity(0.2)
          ),
          child: child,
        ),
      ),
    );
  }
}

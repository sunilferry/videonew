import 'dart:ui';

import 'package:flutter/material.dart';
/**
 *Developed by Suneel kumar 27-01-2022
 */


class FrostedInputBox extends StatelessWidget {
  String? hint;
  Widget? prefixIcon;
  FrostedInputBox({this.hint,this.prefixIcon});
  @override
  Widget build(BuildContext context) {
    return  ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child:  BackdropFilter(
        filter:  ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
        child:  Container(
          decoration: new BoxDecoration(
              color: Colors.grey.shade200.withOpacity(0.2),
            border: Border.all(color: Colors.white70),
            borderRadius: BorderRadius.circular(10)
          ),
          child: TextField(
            decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(color: Colors.white),
                prefixIcon: prefixIcon,
                border: InputBorder.none

            ),

          ),
        ),
      ),
    );
  }
}

import 'package:agora_video_app/Screens/AccountSecurity/account_security.dart';
import 'package:agora_video_app/Screens/Feedback/feedback.dart';
import 'package:agora_video_app/Screens/Home/home_screen.dart';
import 'package:agora_video_app/Screens/HostVerification/host_verification.dart';
import 'package:agora_video_app/Screens/Invitation/invitation.dart';
import 'package:agora_video_app/Screens/Level/my_level.dart';
import 'package:agora_video_app/Screens/Login/login_screen.dart';
import 'package:agora_video_app/Screens/Splash/splash.dart';
import 'package:agora_video_app/Screens/Store/store.dart';
import 'package:agora_video_app/Screens/ViewPorfile/view_profile.dart';
import 'package:agora_video_app/Screens/Wallet/wallet_screen.dart';
import 'package:agora_video_app/Screens/Welcome/welcome_screen.dart';
import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';
import 'package:agora_video_app/helpers/pref_manager.dart';
import 'package:agora_video_app/pages/broadcaster_page.dart';
import 'package:agora_video_app/providers/profile_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'Screens/ConvertDiamond/convert_diamond.dart';
import 'Screens/Country/country_page.dart';
import 'Screens/EditProfile/edit_profile.dart';
import 'Screens/HostLiveData/live_data.dart';
import 'Screens/Setting/settings.dart';
import 'Screens/Signup/signup_screen.dart';
import 'helpers/app_routes.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(statusBarColor: Colors.white));
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => ProfileProvider()),
    ],
    child: MaterialApp(
      theme: ThemeData(
          primarySwatch: Colors.deepPurple, primaryColorDark: kPrimaryColor),
      debugShowCheckedModeBanner: false,
      home: MyApp(),
      initialRoute: '/',
      routes: {
        WELCOME: (context) => WelcomeScreen(),
        LOGIN: (context) => LoginScreen(),
        SIGNUP: (context) => SignUpScreen(),
        BROADCASTER: (context) => Broadcaster(),
        HOME: (context) => HomeScreen(),
        EDIT_PROFILE: (context) => EditProfileScreen(),
        WALLET: (context) => Wallet(),
        STORE: (context) => Store(),
        SETTING: (context) => Setting(),
        LEVEL: (context) => MyLevel(),
        INVITATION: (context) => Invitation(),
        ACCOUNT_SECURITY: (context) => AccountSecurity(),
        HOST_VERIFICATION: (context) => HostVerification(),
        LIVE_DATA: (context) => LiveData(),
        VIEW_PROFILE: (context) => ViewProfile(),
        FEEDBACK: (context) => FeedBack(),
        COUNTRY: (context) => CountryPage(),
        CONVERT_DIAMOND: (context) => ConvertDiamond(),
      },
    ),
  ));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends BaseStateFull<MyApp> {
  PrefManager? prefManager;

  @override
  void initState() {
    super.initState();
    initialize();
  }

  initialize() async {
    prefManager = await PrefManager.getInstance();
    Future.delayed(Duration(seconds: 3), () {
      if (prefManager!.getId().isNotEmpty) {
        Navigator.pushReplacementNamed(context, HOME);
      } else {
        Navigator.pushReplacementNamed(context, WELCOME);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Splash();
  }
}

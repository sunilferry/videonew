// To parse this JSON data, do
//
//     final otpResponse = otpResponseFromJson(jsonString);

import 'dart:convert';

OtpResponse otpResponseFromJson(String str) => OtpResponse.fromJson(json.decode(str));

String otpResponseToJson(OtpResponse data) => json.encode(data.toJson());

class OtpResponse {
  OtpResponse({
    required this.responseCode,
    required this.response,
  });

  String responseCode;
  String response;

  factory OtpResponse.fromJson(Map<String, dynamic> json) => OtpResponse(
    responseCode: json["responseCode"],
    response: json["response"],
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "response": response,
  };
}

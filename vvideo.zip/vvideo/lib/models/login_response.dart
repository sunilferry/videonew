// To parse this JSON data, do
//
//     final loginResponse = loginResponseFromJson(jsonString);

import 'dart:convert';

LoginResponse loginResponseFromJson(String str) => LoginResponse.fromJson(json.decode(str));

String loginResponseToJson(LoginResponse data) => json.encode(data.toJson());

class LoginResponse {
  LoginResponse({
    required this.success,
    required this.message,
    required this.user,
    required this.tokens,
  });

  bool success;
  String message;
  User user;
  Tokens tokens;

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
    success: json["success"],
    message: json["message"],
    user: User.fromJson(json["user"]),
    tokens: Tokens.fromJson(json["tokens"]),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "user": user.toJson(),
    "tokens": tokens.toJson(),
  };
}

class Tokens {
  Tokens({
    required this.access,
    required this.refresh,
  });

  Access access;
  Access refresh;

  factory Tokens.fromJson(Map<String, dynamic> json) => Tokens(
    access: Access.fromJson(json["access"]),
    refresh: Access.fromJson(json["refresh"]),
  );

  Map<String, dynamic> toJson() => {
    "access": access.toJson(),
    "refresh": refresh.toJson(),
  };
}

class Access {
  Access({
    required this.token,
    required this.expires,
  });

  String token;
  DateTime expires;

  factory Access.fromJson(Map<String, dynamic> json) => Access(
    token: json["token"],
    expires: DateTime.parse(json["expires"]),
  );

  Map<String, dynamic> toJson() => {
    "token": token,
    "expires": expires.toIso8601String(),
  };
}

class User {
  User({
    this.dob,
    required this.gender,
    required this.role,
    required this.isEmailVerified,
    this.deviceId,
    required this.isBlocked,
    required this.accountId,
    this.ipAddress,
    required this.bio,
    required this.profileImage,
    required this.country,
    required this.coin,
    required this.language,
    this.name,
    required this.email,
    required this.id,
  });

  dynamic dob;
  String gender;
  String role;
  bool isEmailVerified;
  dynamic deviceId;
  bool isBlocked;
  String accountId;
  dynamic ipAddress;
  String bio;
  String profileImage;
  String country;
  int coin;
  String language;
  dynamic name;
  String email;
  String id;

  factory User.fromJson(Map<String, dynamic> json) => User(
    dob: json["dob"],
    gender: json["gender"],
    role: json["role"],
    isEmailVerified: json["isEmailVerified"],
    deviceId: json["deviceId"],
    isBlocked: json["isBlocked"],
    accountId: json["accountId"],
    ipAddress: json["ipAddress"],
    bio: json["bio"],
    profileImage: json["profileImage"],
    country: json["country"],
    coin: json["coin"],
    language: json["language"],
    name: json["name"],
    email: json["email"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "dob": dob,
    "gender": gender,
    "role": role,
    "isEmailVerified": isEmailVerified,
    "deviceId": deviceId,
    "isBlocked": isBlocked,
    "accountId": accountId,
    "ipAddress": ipAddress,
    "bio": bio,
    "profileImage": profileImage,
    "country": country,
    "coin": coin,
    "language": language,
    "name": name,
    "email": email,
    "id": id,
  };
}

// To parse this JSON data, do
//
//     final profileResponse = profileResponseFromJson(jsonString);

import 'dart:convert';

ProfileResponse profileResponseFromJson(String str) => ProfileResponse.fromJson(json.decode(str));

String profileResponseToJson(ProfileResponse data) => json.encode(data.toJson());

class ProfileResponse {
  ProfileResponse({
    required this.role,
    required this.isEmailVerified,
    required this.name,
    required this.email,
    required this.gender,
    required this.accountId,
    required this.deviceId,
    required this.ipAddress,
    required this.profilePicAddress,
    required this.id,
  });

  String role;
  bool isEmailVerified;
  String name;
  String email;
  String gender;
  String accountId;
  String deviceId;
  String ipAddress;
  String profilePicAddress;
  String id;

  factory ProfileResponse.fromJson(Map<String, dynamic> json) => ProfileResponse(
    role: json["role"],
    isEmailVerified: json["isEmailVerified"],
    name: json["name"],
    email: json["email"],
    gender: json["gender"],
    accountId: json["accountId"],
    deviceId: json["deviceId"],
    ipAddress: json["ipAddress"],
    profilePicAddress: json["profilePicAddress"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "role": role,
    "isEmailVerified": isEmailVerified,
    "name": name,
    "email": email,
    "gender": gender,
    "accountId": accountId,
    "deviceId": deviceId,
    "ipAddress": ipAddress,
    "profilePicAddress": profilePicAddress,
    "id": id,
  };
}

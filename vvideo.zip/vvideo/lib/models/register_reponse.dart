// To parse this JSON data, do
//
//     final registerResponse = registerResponseFromJson(jsonString);

import 'dart:convert';

RegisterResponse registerResponseFromJson(String str) => RegisterResponse.fromJson(json.decode(str));

String registerResponseToJson(RegisterResponse data) => json.encode(data.toJson());

class RegisterResponse {
  RegisterResponse({
    required this.user,
    required this.tokens,
  });

  User user;
  Tokens tokens;

  factory RegisterResponse.fromJson(Map<String, dynamic> json) => RegisterResponse(
    user: User.fromJson(json["user"]),
    tokens: Tokens.fromJson(json["tokens"]),
  );

  Map<String, dynamic> toJson() => {
    "user": user.toJson(),
    "tokens": tokens.toJson(),
  };
}

class Tokens {
  Tokens({
    required this.access,
    required this.refresh,
  });

  Access access;
  Access refresh;

  factory Tokens.fromJson(Map<String, dynamic> json) => Tokens(
    access: Access.fromJson(json["access"]),
    refresh: Access.fromJson(json["refresh"]),
  );

  Map<String, dynamic> toJson() => {
    "access": access.toJson(),
    "refresh": refresh.toJson(),
  };
}

class Access {
  Access({
    required this.token,
    required this.expires,
  });

  String token;
  DateTime expires;

  factory Access.fromJson(Map<String, dynamic> json) => Access(
    token: json["token"],
    expires: DateTime.parse(json["expires"]),
  );

  Map<String, dynamic> toJson() => {
    "token": token,
    "expires": expires.toIso8601String(),
  };
}

class User {
  User({
    required this.dob,
    required this.gender,
    required this.role,
    required this.isEmailVerified,
    required this.deviceId,
    required this.isBlocked,
    required this.accountId,
    required this.ipAddress,
    required this.bio,
    required this.profileImage,
    required this.followings,
    required this.followers,
    required this.fans,
    required this.country,
    required this.name,
    required this.email,
    required this.id,
  });

  DateTime dob;
  String gender;
  String role;
  bool isEmailVerified;
  String deviceId;
  bool isBlocked;
  String accountId;
  String ipAddress;
  String bio;
  String profileImage;
  List<dynamic> followings;
  List<dynamic> followers;
  List<dynamic> fans;
  String country;
  String name;
  String email;
  String id;

  factory User.fromJson(Map<String, dynamic> json) => User(
    dob: DateTime.parse(json["dob"]),
    gender: json["gender"],
    role: json["role"],
    isEmailVerified: json["isEmailVerified"],
    deviceId: json["deviceId"],
    isBlocked: json["isBlocked"],
    accountId: json["accountId"],
    ipAddress: json["ipAddress"],
    bio: json["bio"],
    profileImage: json["profileImage"],
    followings: List<dynamic>.from(json["followings"].map((x) => x)),
    followers: List<dynamic>.from(json["followers"].map((x) => x)),
    fans: List<dynamic>.from(json["fans"].map((x) => x)),
    country: json["country"],
    name: json["name"],
    email: json["email"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "dob": dob.toIso8601String(),
    "gender": gender,
    "role": role,
    "isEmailVerified": isEmailVerified,
    "deviceId": deviceId,
    "isBlocked": isBlocked,
    "accountId": accountId,
    "ipAddress": ipAddress,
    "bio": bio,
    "profileImage": profileImage,
    "followings": List<dynamic>.from(followings.map((x) => x)),
    "followers": List<dynamic>.from(followers.map((x) => x)),
    "fans": List<dynamic>.from(fans.map((x) => x)),
    "country": country,
    "name": name,
    "email": email,
    "id": id,
  };
}

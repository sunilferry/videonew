import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF6F35A5);
const kPinkColor = Color(0xFFD616A9);
const kRedColor = Color(0xFFFC0775);
const kYellowColor = Color(0xFFFECF36);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const kBlueColor = Color(0xFF0BA4E1);

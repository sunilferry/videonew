const APP_ID = 'aeaee646e84449fbab9cc28e9366bb3d';
const Token = '006aeaee646e84449fbab9cc28e9366bb3dIABrhsKfqgOIWSmhiJHog/N3YO6NMOxIB/X9BLfdfi/a0Czax3wAAAAAEADkBngO9Z5FYQEAAQD1nkVh';

const BASE_URL='http://13.232.96.186:3000/v1/';
const register_url='auth/register';
const login_url='auth/login';
const profile_detail_url='users/';
const update_profile_url='users/';

const default_name="😋😋V Video😋😋";
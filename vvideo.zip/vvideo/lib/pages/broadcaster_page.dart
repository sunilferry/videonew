import 'dart:ui';

import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as RtcLocalView;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as RtcRemoteView;
import 'package:agora_rtm/agora_rtm.dart';
import 'package:agora_video_app/constants.dart';
import 'package:agora_video_app/helpers/base_satefull.dart';

import 'package:draggable_widget/draggable_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:lottie/lottie.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:velocity_x/velocity_x.dart';

import '../config.dart';

class Broadcaster extends StatefulWidget {
  @override
  _BroadcasterState createState() => _BroadcasterState();
}

class _BroadcasterState extends BaseStateFull<Broadcaster>
    with TickerProviderStateMixin {
  final messageController = TextEditingController();
  late final AnimationController _controller;
  late LottieComposition composition;
  bool replay = false;
  bool _joined = false;
  int _remoteUid = 0;
  bool _switch = false;
  RtcEngine? engine;

  AgoraRtmClient? _client;
  AgoraRtmChannel? _channel;
  bool _isLogin = false;
  bool _isInChannel = false, muteLocalAudio = true, muteLocalVideo = true;

  bool visiblity = false;
  bool profileVisibility = false;
  bool usersListVisibility = false;

  @override
  void dispose() {
    engine!.leaveChannel();
    engine!.destroy();

    _controller.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    initPlatformState();
    /* _createClient();
    _joinChannel('video');*/
    _controller = AnimationController(vsync: this);
    _controller.addStatusListener((status) {
      print(status);
      if (status == AnimationStatus.completed) {
        _controller.reset();
      }
    });
  }

  // Init the app
  Future<void> initPlatformState() async {
    await [Permission.camera, Permission.microphone, Permission.storage]
        .request();

    // Create RTC client instance
    RtcEngineContext context = RtcEngineContext(APP_ID);
    engine = await RtcEngine.createWithContext(context);
    // Define event handling logic
    if (engine != null) {
      engine!.setEventHandler(RtcEngineEventHandler(
          joinChannelSuccess: (String channel, int uid, int elapsed) {
        print('joinChannelSuccess $channel $uid');
        setState(() {
          _joined = true;
        });
      }, userJoined: (int uid, int elapsed) {
        print('userJoined $uid');
        setState(() {
          _remoteUid = uid;
        });
      }, userOffline: (int uid, UserOfflineReason reason) {
        print('userOffline $uid');
        setState(() {
          _remoteUid = 0;
        });
      }));
      // Enable video
      await engine!.enableVideo();
      // Join channel with channel name as 123
      await engine!.joinChannel(Token, 'video', null, 0);
      // Set channel profile as livestreaming
      await engine!.setChannelProfile(ChannelProfile.LiveBroadcasting);
      // Set user role as broadcaster
      await engine!.setClientRole(ClientRole.Broadcaster);
    }
  }

  muteMice() async {
    await engine!.enableLocalAudio(muteLocalAudio);
  }

  muteVideo() async {
    await engine!.enableLocalVideo(muteLocalVideo);
  }

  final dragController = DragController();

  // Build UI
  @override
  Widget build(BuildContext context) {

    Widget giftWidget = giftSheet();
    Widget profileWidget = userProfile();
    return WillPopScope(
      onWillPop: () {
        if (profileVisibility || usersListVisibility || visiblity) {
          profileVisibility = false;
          usersListVisibility = false;
          visiblity = false;
          setState(() {});
          return Future.value(false);
        } else {
          return Future.value(true);
        }
      },
      child: Stack(children: [
        Scaffold(
          resizeToAvoidBottomInset: false,
          body: Stack(
            children: [
              Center(
                child: _switch ? _renderRemoteVideo() : _renderLocalPreview(),
              ),
              Align(
                alignment: Alignment.topLeft,
                child: Container(
                  width: 100,
                  height: 120,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _switch = !_switch;
                      });
                    },
                    child: Center(
                      child: _switch
                          ? _renderLocalPreview()
                          : _renderRemoteVideo(),
                    ),
                  ),
                ),
              ),

              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  margin: EdgeInsets.only(bottom: 4),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,

                    children: [


                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                              onPressed: () {
                                setState(() {
                                  visiblity = true;
                                });
                              },
                              icon: Icon(Icons.chat_outlined)),
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                child: IconButton(
                                    onPressed: () {
                                      muteLocalAudio = !muteLocalAudio;
                                      muteMice();
                                    },
                                    icon: Icon(Icons.mic)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                radius: 20,
                                child: IconButton(
                                    onPressed: () {
                                      muteLocalVideo = !muteLocalVideo;
                                      muteVideo();
                                    },
                                    icon: Icon(Icons.videocam)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                child: IconButton(
                                    onPressed: () {},
                                    icon: Icon(Icons.videogame_asset)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                child: IconButton(
                                    onPressed: () {
                                      print('hhsdls');
                                      showModalBottomSheet(
                                          backgroundColor: Colors.transparent,
                                          barrierColor: Colors.transparent,
                                          context: context,
                                          builder: (BuildContext context) {
                                            return giftWidget;
                                          });
                                    },
                                    icon: Icon(Icons.card_giftcard)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                child: IconButton(
                                    onPressed: () {}, icon: Icon(Icons.call)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              CircleAvatar(
                                backgroundColor: kPrimaryColor,
                                child: IconButton(
                                    onPressed: () {
                                      _controller.forward();
                                    },
                                    icon: Icon(Icons.close)),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              Lottie.asset(
                                "assets/json_files/call.json",
                                height: 70,
                              ),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),




            ],
          ),

        ),
        Visibility(
          visible: visiblity,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Container(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: 55,
                padding: EdgeInsets.only(right: 8, left: 8),
                color: Colors.white,
                child: Stack(
                  children: <Widget>[
                    Container(
                      alignment: Alignment.centerLeft,
                      margin: EdgeInsets.only(right: 50),
                      child: TextFormField(
                        controller: messageController,
                        decoration: InputDecoration(
                            hintText: 'Say something.....',
                            filled: true,
                            contentPadding: EdgeInsets.only(
                                top: 4, bottom: 4, left: 12, right: 8),
                            fillColor: kPrimaryLightColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                            )),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: CircleAvatar(
                        child: InkWell(
                            onTap: () {
                              _toggleSendChannelMessage();
                            },
                            child: Icon(Icons.send)),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
        Lottie.asset(
          'assets/json_files/rose.json',
          controller: _controller,
          onLoaded: (composition) {
            this.composition = composition;
            _controller.duration = composition.duration;
            // _controller.forward();
          },
        ),
        Container(
          height: 100,
          child: Material(
            color: Colors.transparent,
            child: Stack(

              children: [
                Container(
                  constraints: BoxConstraints(minWidth: 100, maxWidth: 200),
                  padding: EdgeInsets.all(4),
                  margin: EdgeInsets.only(top: 30, left: 16),
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      'assets/images/girl.jpg'
                          .circularAssetImage(radius: 15)
                          .onTap(() {
                        showModalBottomSheet(
                            barrierColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            context: context,
                            builder: (context) {
                              return profileWidget;
                            });
                      }),
                      4.widthBox,
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('bsfjkdn gfxngkl fdmg fdklg fd gfndgfd jl$default_name',
                              style:
                                  TextStyle(fontSize: 10, color: Colors.white),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                'Lv0'.text.size(6).white.make(),
                              ],
                            )
                          ],
                        ),
                      ),

                      4.widthBox,
                      Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [kPrimaryColor, kPinkColor]),
                            borderRadius: BorderRadius.circular(20)),
                        child: Center(
                          child: Icon(
                            Icons.add,
                            color: Colors.white,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    margin: EdgeInsets.only(top: 30, right: 16),
                    height: 30,
                    width: 30,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [kPrimaryColor, kPinkColor]),
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      onTap: () {
                        usersListVisibility = !usersListVisibility;
                        setState(() {});
                      },
                      child: Center(
                        child: Icon(
                          Icons.group,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Visibility(
          visible: usersListVisibility,
          child: Material(
            color: Colors.transparent,
            child: Align(
                alignment: Alignment.topRight, child: usersListWidget(context)),
          ),
        ),
      ]),
    );
  }

  Widget usersListWidget(BuildContext context) {
    return SafeArea(
      child: Container(
        width: context.percentWidth * 50,
        height: context.screenHeight,
        child: ClipRRect(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(8), bottomLeft: Radius.circular(8)),
          child: new BackdropFilter(
            filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
            child: new Container(
              width: MediaQuery.of(context).size.width,
              decoration: new BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        Colors.purple.shade200.withOpacity(0.5),
                        Color(0xFFF3EB9B).withOpacity(0.5),
                      ]),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(8),
                      bottomLeft: Radius.circular(8))),
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [kPrimaryColor, kPinkColor])),
                          child: 'Online Users'.text.white.makeCentered()),
                      IconButton(
                          onPressed: () {
                            usersListVisibility = !usersListVisibility;
                            setState(() {});
                          },
                          icon: Icon(
                            Icons.close,
                            color: Colors.white,
                          ))
                    ],
                  ),
                  10.heightBox,
                  ListView.builder(
                      shrinkWrap: true,
                      itemCount: 5,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          margin: EdgeInsets.only(
                              left: 8, right: 8, top: 8, bottom: 4),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              'assets/images/girl.jpg'
                                  .circularAssetImage(radius: 18),
                              8.widthBox,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'Papa ki pari',
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.black),
                                  ),
                                  Text(
                                    'Lv0',
                                    style: TextStyle(fontSize: 8),
                                  )
                                ],
                              )
                            ],
                          ),
                        );
                      })
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget giftSheet() {
    return Container(
      margin: EdgeInsets.all(6),
      child: new ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: new BackdropFilter(
          filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
          child: new Container(
            width: MediaQuery.of(context).size.width,
            decoration: new BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [
                      Colors.purple.shade200.withOpacity(0.5),
                      Color(0xFFF3EB9B).withOpacity(0.5),
                    ]),
                borderRadius: BorderRadius.circular(8)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    margin: EdgeInsets.all(8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Popular',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: kPrimaryColor),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset(
                              'assets/icons/diamond.png',
                              height: 18,
                              width: 18,
                            ),
                            SizedBox(
                              width: 4,
                            ),
                            Text(
                              '0',
                              style: TextStyle(fontSize: 20),
                            ),
                            SizedBox(
                              width: 4,
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              size: 18,
                            )
                          ],
                        )
                      ],
                    )),
                GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                    ),
                    itemCount: 8,
                    shrinkWrap: true,
                    primary: false,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        margin: EdgeInsets.only(left: 4, right: 4),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.network(
                              'https://www.freeiconspng.com/thumbs/rose-png/rose-png-25.png',
                              height: 40,
                              width: 40,
                            ),
                            Text(
                              'Rose',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.white),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  'assets/icons/diamond.png',
                                  height: 12,
                                  width: 12,
                                ),
                                4.widthBox,
                                '199'.text.white.size(8).make(),
                              ],
                            )
                          ],
                        ),
                      );
                    }),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    height: 35,
                    width: 120,
                    margin: EdgeInsets.all(8),

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(width: 1,color: kPrimaryColor)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          flex:1,
                          child: Text(
                            '1',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 16,color: kPrimaryColor),
                          ),
                        ),
                        Expanded(
                          flex:1,
                          child: Container(
                            height: 35,
                              decoration: BoxDecoration(
                                  color: kPrimaryColor,
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(18),
                                      bottomRight: Radius.circular(18))),
                              child: Center(
                                child: Text(
                                  'Send',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 16),
                                ),
                              )).onTap(() { _controller.forward();}),
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Local preview
  Widget _renderLocalPreview() {
    if (_joined) {
      return RtcLocalView.SurfaceView();
    } else {
      return CircularProgressIndicator();
    }
  }

  Widget _renderRemoteVideo() {
    if (_remoteUid != 0) {
      return RtcRemoteView.SurfaceView(
        uid: _remoteUid,
        channelId: "video",
      );
    } else {
      return Text(
        '',
        textAlign: TextAlign.center,
      );
    }
  }

  void _createClient() async {
    _client = await AgoraRtmClient.createInstance(APP_ID);
    _client?.onMessageReceived = (AgoraRtmMessage message, String peerId) {
      _log("Peer msg: " + peerId + ", msg: " + (message.text));
    };
    _client?.onConnectionStateChanged = (int state, int reason) {
      _log('Connection state changed: ' +
          state.toString() +
          ', reason: ' +
          reason.toString());
      if (state == 5) {
        _client?.logout();
        _log('Logout.');
        setState(() {
          _isLogin = false;
        });
      }
    };
  }

  _joinChannel(String channelId) async {
    try {
      _channel = await _createChannel(channelId);
      await _channel?.join();
      _log('Join channel success.');

      setState(() {
        _isInChannel = true;
      });
    } catch (errorCode) {
      _log('Join channel error: ' + errorCode.toString());
    }
  }

  Future<AgoraRtmChannel?> _createChannel(String name) async {
    AgoraRtmChannel? channel = await _client?.createChannel(name);
    if (channel != null) {
      channel.onMemberJoined = (AgoraRtmMember member) {
        _log("Member joined: " +
            member.userId +
            ', channel: ' +
            member.channelId);
      };
      channel.onMemberLeft = (AgoraRtmMember member) {
        _log(
            "Member left: " + member.userId + ', channel: ' + member.channelId);
      };
      channel.onMessageReceived =
          (AgoraRtmMessage message, AgoraRtmMember member) {
        print('mffd');
        _log(
            "Channel msg: " + member.userId + ", msg: " + (message.text));
      };
    }
    return channel;
  }

  void _toggleSendChannelMessage() async {
    String text = messageController.text;
    if (text.isEmpty) {
      _log('Please input text to send.');
      return;
    }
    try {
      await _channel?.sendMessage(AgoraRtmMessage.fromText(text));
      _log('Send channel message success.');
    } catch (errorCode) {
      _log('Send channel message error: ' + errorCode.toString());
    }
  }

  void _log(String info) {
    print(info);
  }

  Widget userProfile() {
    return Container(
      margin: EdgeInsets.all(6),
      child: new ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: new BackdropFilter(
          filter: new ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
          child: new Container(
            width: MediaQuery.of(context).size.width,
            decoration: new BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [
                      Colors.purple.shade200.withOpacity(0.5),
                      Color(0xFFF3EB9B).withOpacity(0.5),
                    ]),
                borderRadius: BorderRadius.circular(8)),
            child: Container(
              margin: EdgeInsets.all(8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      'Report'.text.make(),
                      Container(
                        padding: EdgeInsets.only(
                            left: 8, right: 8, top: 4, bottom: 4),
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [kPrimaryColor, kPinkColor]),
                            borderRadius: BorderRadius.circular(16)),
                        child: '+Follow'.text.white.size(12).make(),
                      )
                    ],
                  ),
                  20.heightBox,
                  'assets/images/girl.jpg'.circularAssetImage(radius: 30),
                  10.heightBox,
                  Text(
                    prefManager == null ? 'Guest' : prefManager!.getName(),
                    style: TextStyle(color: Colors.white),
                  ),
                  10.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.only(
                            left: 6, right: 6, top: 2, bottom: 2),
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [kPrimaryColor, kPinkColor]),
                            borderRadius: BorderRadius.circular(16)),
                        child: '+Lv6'.text.white.size(8).make(),
                      ),
                      20.widthBox,
                      Container(
                        padding: EdgeInsets.only(
                            left: 6, right: 6, top: 2, bottom: 2),
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [Colors.deepPurple, Colors.deepPurple]),
                            borderRadius: BorderRadius.circular(16)),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset(
                              'assets/icons/india.png',
                              height: 12,
                              width: 14,
                            ),
                            4.widthBox,
                            'India'.text.white.size(8).make()
                          ],
                        ),
                      ),
                      20.widthBox,
                      Container(
                        padding: EdgeInsets.only(
                            left: 6, right: 6, top: 2, bottom: 2),
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [Colors.deepPurple, Colors.deepPurple]),
                            borderRadius: BorderRadius.circular(16)),
                        child: 'Hindi-English'.text.white.size(8).make(),
                      )
                    ],
                  ),
                  20.heightBox,
                  Container(
                    width: context.percentWidth * 50,
                    padding: EdgeInsets.only(top: 12, bottom: 12),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [kYellowColor, kRedColor]),
                        borderRadius: BorderRadius.circular(25)),
                    child: 'Send gift'.text.white.makeCentered(),
                  ),
                  10.heightBox,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
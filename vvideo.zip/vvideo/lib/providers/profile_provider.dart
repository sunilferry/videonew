import 'package:agora_video_app/models/profile_model.dart';
import 'package:flutter/foundation.dart';

class ProfileProvider extends ChangeNotifier {
  ProfileResponse? profileResponse;

  changeData(ProfileResponse profileResponse) {
    this.profileResponse = profileResponse;
    notifyListeners();
  }
}

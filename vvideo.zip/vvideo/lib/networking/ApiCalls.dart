import 'dart:convert';

import 'package:agora_video_app/config.dart';
import 'package:agora_video_app/models/login_response.dart';
import 'package:agora_video_app/models/profile_model.dart';
import 'package:agora_video_app/models/register_reponse.dart';
import 'package:http/http.dart' as http;

class ApiCalls {
  Future<RegisterResponse?> register(final requestParam) async {
    try {
      final req = json.encode(requestParam);
      print(req);
      final res = await http.post(Uri.parse(BASE_URL + register_url),
          body: req, headers: {'Content-Type': 'application/json'});
      print(res.body);
      print(res.statusCode);
      if (res.statusCode == 200) {
        return registerResponseFromJson(res.body);
      } else {
        return null;
      }
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future<LoginResponse?> login(final requestParam) async {
    try {
      final req = json.encode(requestParam);
      print(req);
      final res = await http.post(Uri.parse(BASE_URL + login_url),
          body: req, headers: {'Content-Type': 'application/json'});
      print(res.body);
      if (res.statusCode == 200) {
        return loginResponseFromJson(res.body);
      } else {
        throw 'found error';
      }
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future<ProfileResponse?> getProfile(String token,String id) async {
    try {

      final res = await http.get(Uri.parse(BASE_URL + profile_detail_url+id),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+token
          });
      print(res.body);
      if (res.statusCode == 200) {
        return profileResponseFromJson(res.body);
      } else {
        return null;
      }
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future<LoginResponse?> updateProfile(final requestParam,String token,String id) async {
    try {
      final req = json.encode(requestParam);
      final res = await http.patch(Uri.parse(BASE_URL + profile_detail_url+id),
          body: req,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+token
          });
      print(res.body);
      if (res.statusCode == 200) {
        return loginResponseFromJson(res.body);
      } else {
        return null;
      }
    } catch (e) {
      print(e.toString());
      return null;
    }
  }
}

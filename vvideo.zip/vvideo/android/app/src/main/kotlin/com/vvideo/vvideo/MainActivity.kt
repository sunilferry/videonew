package com.vvideo.vvideo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
